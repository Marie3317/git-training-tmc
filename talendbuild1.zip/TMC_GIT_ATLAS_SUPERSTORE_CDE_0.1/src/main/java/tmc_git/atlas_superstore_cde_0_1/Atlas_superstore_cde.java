
package tmc_git.atlas_superstore_cde_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.SQLike;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: Atlas_superstore_cde Purpose: Entraînement Talend<br>
 * Description: Votre mission si vous l’acceptez sera de construire un Data
 * Warehouse (DWH) permettant de répondre au besoin d’Atlas Superstore. <br>
 * 
 * @author LEFEBVRE, Marie
 * @version 8.0.1.20230815_1353-patch
 * @status
 */
public class Atlas_superstore_cde implements TalendJob {
	static {
		System.setProperty("TalendJob.log", "Atlas_superstore_cde.log");
	}

	private static org.apache.logging.log4j.Logger log = org.apache.logging.log4j.LogManager
			.getLogger(Atlas_superstore_cde.class);

	protected static void logIgnoredError(String message, Throwable cause) {
		log.error(message, cause);

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "Atlas_superstore_cde";
	private final String projectName = "TMC_GIT";
	public Integer errorCode = null;
	private String currentComponent = "";

	private String cLabel = null;

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private final JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName,
			"_EomQIGRfEe6hdfxx25NesQ", "0.1");
	private org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;

	private RunStat runStat = new RunStat(talendJobLog, System.getProperty("audit.interval"));

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;

		private String currentComponent = null;
		private String cLabel = null;

		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		private TalendException(Exception e, String errorComponent, String errorComponentLabel,
				final java.util.Map<String, Object> globalMap) {
			this(e, errorComponent, globalMap);
			this.cLabel = errorComponentLabel;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					Atlas_superstore_cde.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(Atlas_superstore_cde.this, new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
						if (enableLogStash) {
							talendJobLog.addJobExceptionMessage(currentComponent, cLabel, null, e);
							talendJobLogProcess(globalMap);
						}
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tDBConnection_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFilterRow_5_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBOutput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tLogRow_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBInput_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tPostjob_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBClose_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBClose_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_Cdes_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tDBInput_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendJobLog_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		talendJobLog_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileInputDelimited_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBInput_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tPostjob_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBClose_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void talendJobLog_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBConnection_1");
		org.slf4j.MDC.put("_subJobPid", "WYaQoJ_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tDBConnection_1 begin ] start
				 */

				ok_Hash.put("tDBConnection_1", false);
				start_Hash.put("tDBConnection_1", System.currentTimeMillis());

				currentComponent = "tDBConnection_1";

				int tos_count_tDBConnection_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBConnection_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBConnection_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
							log4jParamters_tDBConnection_1.append("Parameters:");
							log4jParamters_tDBConnection_1.append("DB_VERSION" + " = " + "MARIADB");
							log4jParamters_tDBConnection_1.append(" | ");
							log4jParamters_tDBConnection_1.append("HOST" + " = " + "\"localhost\"");
							log4jParamters_tDBConnection_1.append(" | ");
							log4jParamters_tDBConnection_1.append("PORT" + " = " + "\"3306\"");
							log4jParamters_tDBConnection_1.append(" | ");
							log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "\"atlas_superstore\"");
							log4jParamters_tDBConnection_1.append(" | ");
							log4jParamters_tDBConnection_1
									.append("PROPERTIES" + " = " + "\"noDatetimeStringSync=true\"");
							log4jParamters_tDBConnection_1.append(" | ");
							log4jParamters_tDBConnection_1.append("USER" + " = " + "\"root\"");
							log4jParamters_tDBConnection_1.append(" | ");
							log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf(
									"enc:routine.encryption.key.v1:hb2i/s0KAuuROqr1xBEgmjWL1q6LjiUSOmnRb3SstxxkMG9MkvHvcpeMurU=")
									.substring(0, 4) + "...");
							log4jParamters_tDBConnection_1.append(" | ");
							log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
							log4jParamters_tDBConnection_1.append(" | ");
							log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
							log4jParamters_tDBConnection_1.append(" | ");
							log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "true");
							log4jParamters_tDBConnection_1.append(" | ");
							log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlConnection");
							log4jParamters_tDBConnection_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBConnection_1 - " + (log4jParamters_tDBConnection_1));
						}
					}
					new BytesLimit65535_tDBConnection_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBConnection_1", "tDBConnection_1", "tMysqlConnection");
					talendJobLogProcess(globalMap);
				}

				String properties_tDBConnection_1 = "noDatetimeStringSync=true";
				if (properties_tDBConnection_1 == null || properties_tDBConnection_1.trim().length() == 0) {
					properties_tDBConnection_1 = "rewriteBatchedStatements=true&allowLoadLocalInfile=true";
				} else {
					if (!properties_tDBConnection_1.contains("rewriteBatchedStatements=")) {
						properties_tDBConnection_1 += "&rewriteBatchedStatements=true";
					}

					if (!properties_tDBConnection_1.contains("allowLoadLocalInfile=")) {
						properties_tDBConnection_1 += "&allowLoadLocalInfile=true";
					}
				}

				String url_tDBConnection_1 = "jdbc:mariadb://" + "localhost" + ":" + "3306" + "/" + "atlas_superstore"
						+ "?" + properties_tDBConnection_1;
				String dbUser_tDBConnection_1 = "root";

				final String decryptedPassword_tDBConnection_1 = routines.system.PasswordEncryptUtil.decryptPassword(
						"enc:routine.encryption.key.v1:Lsmc5mc1YidlH9+J+hp1G/hb/A3nvXnlqtrJ6h9UuvOHZ7K9ssuwPDkt55I=");
				String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;

				java.sql.Connection conn_tDBConnection_1 = null;

				String driverClass_tDBConnection_1 = "org.mariadb.jdbc.Driver";
				java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
				globalMap.put("driverClass_tDBConnection_1", driverClass_tDBConnection_1);

				log.debug("tDBConnection_1 - Driver ClassName: " + driverClass_tDBConnection_1 + ".");

				log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '"
						+ dbUser_tDBConnection_1 + "'.");

				conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1, dbUser_tDBConnection_1,
						dbPwd_tDBConnection_1);
				log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");

				globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
				if (null != conn_tDBConnection_1) {

					log.debug("tDBConnection_1 - Connection is set auto commit to 'true'.");
					conn_tDBConnection_1.setAutoCommit(true);
				}

				globalMap.put("db_tDBConnection_1", "atlas_superstore");

				/**
				 * [tDBConnection_1 begin ] stop
				 */

				/**
				 * [tDBConnection_1 main ] start
				 */

				currentComponent = "tDBConnection_1";

				tos_count_tDBConnection_1++;

				/**
				 * [tDBConnection_1 main ] stop
				 */

				/**
				 * [tDBConnection_1 process_data_begin ] start
				 */

				currentComponent = "tDBConnection_1";

				/**
				 * [tDBConnection_1 process_data_begin ] stop
				 */

				/**
				 * [tDBConnection_1 process_data_end ] start
				 */

				currentComponent = "tDBConnection_1";

				/**
				 * [tDBConnection_1 process_data_end ] stop
				 */

				/**
				 * [tDBConnection_1 end ] start
				 */

				currentComponent = "tDBConnection_1";

				if (log.isDebugEnabled())
					log.debug("tDBConnection_1 - " + ("Done."));

				ok_Hash.put("tDBConnection_1", true);
				end_Hash.put("tDBConnection_1", System.currentTimeMillis());

				/**
				 * [tDBConnection_1 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBConnection_1 finally ] start
				 */

				currentComponent = "tDBConnection_1";

				/**
				 * [tDBConnection_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}

	public static class cde_cleanedStruct implements routines.system.IPersistableRow<cde_cleanedStruct> {
		final static byte[] commonByteArrayLock_TMC_GIT_Atlas_superstore_cde = new byte[0];
		static byte[] commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int numero_commande;

		public int getNumero_commande() {
			return this.numero_commande;
		}

		public Boolean numero_commandeIsNullable() {
			return false;
		}

		public Boolean numero_commandeIsKey() {
			return true;
		}

		public Integer numero_commandeLength() {
			return 11;
		}

		public Integer numero_commandePrecision() {
			return 0;
		}

		public String numero_commandeDefault() {

			return "";

		}

		public String numero_commandeComment() {

			return "";

		}

		public String numero_commandePattern() {

			return "";

		}

		public String numero_commandeOriginalDbColumnName() {

			return "numero_commande";

		}

		public String reference_produit;

		public String getReference_produit() {
			return this.reference_produit;
		}

		public Boolean reference_produitIsNullable() {
			return false;
		}

		public Boolean reference_produitIsKey() {
			return false;
		}

		public Integer reference_produitLength() {
			return 50;
		}

		public Integer reference_produitPrecision() {
			return 0;
		}

		public String reference_produitDefault() {

			return null;

		}

		public String reference_produitComment() {

			return "";

		}

		public String reference_produitPattern() {

			return "";

		}

		public String reference_produitOriginalDbColumnName() {

			return "reference_produit";

		}

		public Integer CONDITIONNEMENT;

		public Integer getCONDITIONNEMENT() {
			return this.CONDITIONNEMENT;
		}

		public Boolean CONDITIONNEMENTIsNullable() {
			return true;
		}

		public Boolean CONDITIONNEMENTIsKey() {
			return false;
		}

		public Integer CONDITIONNEMENTLength() {
			return null;
		}

		public Integer CONDITIONNEMENTPrecision() {
			return null;
		}

		public String CONDITIONNEMENTDefault() {

			return null;

		}

		public String CONDITIONNEMENTComment() {

			return "";

		}

		public String CONDITIONNEMENTPattern() {

			return "";

		}

		public String CONDITIONNEMENTOriginalDbColumnName() {

			return "CONDITIONNEMENT";

		}

		public Float PRIX_UNITAIRE;

		public Float getPRIX_UNITAIRE() {
			return this.PRIX_UNITAIRE;
		}

		public Boolean PRIX_UNITAIREIsNullable() {
			return true;
		}

		public Boolean PRIX_UNITAIREIsKey() {
			return false;
		}

		public Integer PRIX_UNITAIRELength() {
			return null;
		}

		public Integer PRIX_UNITAIREPrecision() {
			return null;
		}

		public String PRIX_UNITAIREDefault() {

			return null;

		}

		public String PRIX_UNITAIREComment() {

			return "";

		}

		public String PRIX_UNITAIREPattern() {

			return "";

		}

		public String PRIX_UNITAIREOriginalDbColumnName() {

			return "PRIX_UNITAIRE";

		}

		public int code_client;

		public int getCode_client() {
			return this.code_client;
		}

		public Boolean code_clientIsNullable() {
			return false;
		}

		public Boolean code_clientIsKey() {
			return false;
		}

		public Integer code_clientLength() {
			return 11;
		}

		public Integer code_clientPrecision() {
			return 0;
		}

		public String code_clientDefault() {

			return "";

		}

		public String code_clientComment() {

			return "";

		}

		public String code_clientPattern() {

			return "";

		}

		public String code_clientOriginalDbColumnName() {

			return "code_client";

		}

		public int quantite;

		public int getQuantite() {
			return this.quantite;
		}

		public Boolean quantiteIsNullable() {
			return false;
		}

		public Boolean quantiteIsKey() {
			return false;
		}

		public Integer quantiteLength() {
			return 11;
		}

		public Integer quantitePrecision() {
			return 0;
		}

		public String quantiteDefault() {

			return "";

		}

		public String quantiteComment() {

			return "";

		}

		public String quantitePattern() {

			return "";

		}

		public String quantiteOriginalDbColumnName() {

			return "quantite";

		}

		public java.util.Date date_commande;

		public java.util.Date getDate_commande() {
			return this.date_commande;
		}

		public Boolean date_commandeIsNullable() {
			return false;
		}

		public Boolean date_commandeIsKey() {
			return false;
		}

		public Integer date_commandeLength() {
			return 19;
		}

		public Integer date_commandePrecision() {
			return 0;
		}

		public String date_commandeDefault() {

			return null;

		}

		public String date_commandeComment() {

			return "";

		}

		public String date_commandePattern() {

			return "dd/MM/yyyy HH:mm:ss";

		}

		public String date_commandeOriginalDbColumnName() {

			return "date_commande";

		}

		public int is_commande_annulee;

		public int getIs_commande_annulee() {
			return this.is_commande_annulee;
		}

		public Boolean is_commande_annuleeIsNullable() {
			return false;
		}

		public Boolean is_commande_annuleeIsKey() {
			return false;
		}

		public Integer is_commande_annuleeLength() {
			return 1;
		}

		public Integer is_commande_annuleePrecision() {
			return 0;
		}

		public String is_commande_annuleeDefault() {

			return "";

		}

		public String is_commande_annuleeComment() {

			return "";

		}

		public String is_commande_annuleePattern() {

			return "";

		}

		public String is_commande_annuleeOriginalDbColumnName() {

			return "is_commande_annulee";

		}

		public String nom_magasin;

		public String getNom_magasin() {
			return this.nom_magasin;
		}

		public Boolean nom_magasinIsNullable() {
			return false;
		}

		public Boolean nom_magasinIsKey() {
			return false;
		}

		public Integer nom_magasinLength() {
			return 255;
		}

		public Integer nom_magasinPrecision() {
			return 0;
		}

		public String nom_magasinDefault() {

			return null;

		}

		public String nom_magasinComment() {

			return "";

		}

		public String nom_magasinPattern() {

			return "";

		}

		public String nom_magasinOriginalDbColumnName() {

			return "nom_magasin";

		}

		public String pays_magasin;

		public String getPays_magasin() {
			return this.pays_magasin;
		}

		public Boolean pays_magasinIsNullable() {
			return false;
		}

		public Boolean pays_magasinIsKey() {
			return false;
		}

		public Integer pays_magasinLength() {
			return 255;
		}

		public Integer pays_magasinPrecision() {
			return 0;
		}

		public String pays_magasinDefault() {

			return null;

		}

		public String pays_magasinComment() {

			return "";

		}

		public String pays_magasinPattern() {

			return "";

		}

		public String pays_magasinOriginalDbColumnName() {

			return "pays_magasin";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.numero_commande;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final cde_cleanedStruct other = (cde_cleanedStruct) obj;

			if (this.numero_commande != other.numero_commande)
				return false;

			return true;
		}

		public void copyDataTo(cde_cleanedStruct other) {

			other.numero_commande = this.numero_commande;
			other.reference_produit = this.reference_produit;
			other.CONDITIONNEMENT = this.CONDITIONNEMENT;
			other.PRIX_UNITAIRE = this.PRIX_UNITAIRE;
			other.code_client = this.code_client;
			other.quantite = this.quantite;
			other.date_commande = this.date_commande;
			other.is_commande_annulee = this.is_commande_annulee;
			other.nom_magasin = this.nom_magasin;
			other.pays_magasin = this.pays_magasin;

		}

		public void copyKeysDataTo(cde_cleanedStruct other) {

			other.numero_commande = this.numero_commande;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TMC_GIT_Atlas_superstore_cde.length) {
					if (length < 1024 && commonByteArray_TMC_GIT_Atlas_superstore_cde.length == 0) {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[1024];
					} else {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length);
				strReturn = new String(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TMC_GIT_Atlas_superstore_cde.length) {
					if (length < 1024 && commonByteArray_TMC_GIT_Atlas_superstore_cde.length == 0) {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[1024];
					} else {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length);
				strReturn = new String(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TMC_GIT_Atlas_superstore_cde) {

				try {

					int length = 0;

					this.numero_commande = dis.readInt();

					this.reference_produit = readString(dis);

					this.CONDITIONNEMENT = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PRIX_UNITAIRE = null;
					} else {
						this.PRIX_UNITAIRE = dis.readFloat();
					}

					this.code_client = dis.readInt();

					this.quantite = dis.readInt();

					this.date_commande = readDate(dis);

					this.is_commande_annulee = dis.readInt();

					this.nom_magasin = readString(dis);

					this.pays_magasin = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_TMC_GIT_Atlas_superstore_cde) {

				try {

					int length = 0;

					this.numero_commande = dis.readInt();

					this.reference_produit = readString(dis);

					this.CONDITIONNEMENT = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PRIX_UNITAIRE = null;
					} else {
						this.PRIX_UNITAIRE = dis.readFloat();
					}

					this.code_client = dis.readInt();

					this.quantite = dis.readInt();

					this.date_commande = readDate(dis);

					this.is_commande_annulee = dis.readInt();

					this.nom_magasin = readString(dis);

					this.pays_magasin = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.numero_commande);

				// String

				writeString(this.reference_produit, dos);

				// Integer

				writeInteger(this.CONDITIONNEMENT, dos);

				// Float

				if (this.PRIX_UNITAIRE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.PRIX_UNITAIRE);
				}

				// int

				dos.writeInt(this.code_client);

				// int

				dos.writeInt(this.quantite);

				// java.util.Date

				writeDate(this.date_commande, dos);

				// int

				dos.writeInt(this.is_commande_annulee);

				// String

				writeString(this.nom_magasin, dos);

				// String

				writeString(this.pays_magasin, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.numero_commande);

				// String

				writeString(this.reference_produit, dos);

				// Integer

				writeInteger(this.CONDITIONNEMENT, dos);

				// Float

				if (this.PRIX_UNITAIRE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.PRIX_UNITAIRE);
				}

				// int

				dos.writeInt(this.code_client);

				// int

				dos.writeInt(this.quantite);

				// java.util.Date

				writeDate(this.date_commande, dos);

				// int

				dos.writeInt(this.is_commande_annulee);

				// String

				writeString(this.nom_magasin, dos);

				// String

				writeString(this.pays_magasin, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("numero_commande=" + String.valueOf(numero_commande));
			sb.append(",reference_produit=" + reference_produit);
			sb.append(",CONDITIONNEMENT=" + String.valueOf(CONDITIONNEMENT));
			sb.append(",PRIX_UNITAIRE=" + String.valueOf(PRIX_UNITAIRE));
			sb.append(",code_client=" + String.valueOf(code_client));
			sb.append(",quantite=" + String.valueOf(quantite));
			sb.append(",date_commande=" + String.valueOf(date_commande));
			sb.append(",is_commande_annulee=" + String.valueOf(is_commande_annulee));
			sb.append(",nom_magasin=" + nom_magasin);
			sb.append(",pays_magasin=" + pays_magasin);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(numero_commande);

			sb.append("|");

			if (reference_produit == null) {
				sb.append("<null>");
			} else {
				sb.append(reference_produit);
			}

			sb.append("|");

			if (CONDITIONNEMENT == null) {
				sb.append("<null>");
			} else {
				sb.append(CONDITIONNEMENT);
			}

			sb.append("|");

			if (PRIX_UNITAIRE == null) {
				sb.append("<null>");
			} else {
				sb.append(PRIX_UNITAIRE);
			}

			sb.append("|");

			sb.append(code_client);

			sb.append("|");

			sb.append(quantite);

			sb.append("|");

			if (date_commande == null) {
				sb.append("<null>");
			} else {
				sb.append(date_commande);
			}

			sb.append("|");

			sb.append(is_commande_annulee);

			sb.append("|");

			if (nom_magasin == null) {
				sb.append("<null>");
			} else {
				sb.append(nom_magasin);
			}

			sb.append("|");

			if (pays_magasin == null) {
				sb.append("<null>");
			} else {
				sb.append(pays_magasin);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(cde_cleanedStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.numero_commande, other.numero_commande);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class cde_filtreesStruct implements routines.system.IPersistableRow<cde_filtreesStruct> {
		final static byte[] commonByteArrayLock_TMC_GIT_Atlas_superstore_cde = new byte[0];
		static byte[] commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int numero_commande;

		public int getNumero_commande() {
			return this.numero_commande;
		}

		public Boolean numero_commandeIsNullable() {
			return false;
		}

		public Boolean numero_commandeIsKey() {
			return true;
		}

		public Integer numero_commandeLength() {
			return 11;
		}

		public Integer numero_commandePrecision() {
			return 0;
		}

		public String numero_commandeDefault() {

			return "";

		}

		public String numero_commandeComment() {

			return "";

		}

		public String numero_commandePattern() {

			return "";

		}

		public String numero_commandeOriginalDbColumnName() {

			return "numero_commande";

		}

		public String reference_produit;

		public String getReference_produit() {
			return this.reference_produit;
		}

		public Boolean reference_produitIsNullable() {
			return false;
		}

		public Boolean reference_produitIsKey() {
			return false;
		}

		public Integer reference_produitLength() {
			return 50;
		}

		public Integer reference_produitPrecision() {
			return 0;
		}

		public String reference_produitDefault() {

			return null;

		}

		public String reference_produitComment() {

			return "";

		}

		public String reference_produitPattern() {

			return "";

		}

		public String reference_produitOriginalDbColumnName() {

			return "reference_produit";

		}

		public Integer CONDITIONNEMENT;

		public Integer getCONDITIONNEMENT() {
			return this.CONDITIONNEMENT;
		}

		public Boolean CONDITIONNEMENTIsNullable() {
			return true;
		}

		public Boolean CONDITIONNEMENTIsKey() {
			return false;
		}

		public Integer CONDITIONNEMENTLength() {
			return null;
		}

		public Integer CONDITIONNEMENTPrecision() {
			return null;
		}

		public String CONDITIONNEMENTDefault() {

			return null;

		}

		public String CONDITIONNEMENTComment() {

			return "";

		}

		public String CONDITIONNEMENTPattern() {

			return "";

		}

		public String CONDITIONNEMENTOriginalDbColumnName() {

			return "CONDITIONNEMENT";

		}

		public Float PRIX_UNITAIRE;

		public Float getPRIX_UNITAIRE() {
			return this.PRIX_UNITAIRE;
		}

		public Boolean PRIX_UNITAIREIsNullable() {
			return true;
		}

		public Boolean PRIX_UNITAIREIsKey() {
			return false;
		}

		public Integer PRIX_UNITAIRELength() {
			return null;
		}

		public Integer PRIX_UNITAIREPrecision() {
			return null;
		}

		public String PRIX_UNITAIREDefault() {

			return null;

		}

		public String PRIX_UNITAIREComment() {

			return "";

		}

		public String PRIX_UNITAIREPattern() {

			return "";

		}

		public String PRIX_UNITAIREOriginalDbColumnName() {

			return "PRIX_UNITAIRE";

		}

		public int code_client;

		public int getCode_client() {
			return this.code_client;
		}

		public Boolean code_clientIsNullable() {
			return false;
		}

		public Boolean code_clientIsKey() {
			return false;
		}

		public Integer code_clientLength() {
			return 11;
		}

		public Integer code_clientPrecision() {
			return 0;
		}

		public String code_clientDefault() {

			return "";

		}

		public String code_clientComment() {

			return "";

		}

		public String code_clientPattern() {

			return "";

		}

		public String code_clientOriginalDbColumnName() {

			return "code_client";

		}

		public int quantite;

		public int getQuantite() {
			return this.quantite;
		}

		public Boolean quantiteIsNullable() {
			return false;
		}

		public Boolean quantiteIsKey() {
			return false;
		}

		public Integer quantiteLength() {
			return 11;
		}

		public Integer quantitePrecision() {
			return 0;
		}

		public String quantiteDefault() {

			return "";

		}

		public String quantiteComment() {

			return "";

		}

		public String quantitePattern() {

			return "";

		}

		public String quantiteOriginalDbColumnName() {

			return "quantite";

		}

		public java.util.Date date_commande;

		public java.util.Date getDate_commande() {
			return this.date_commande;
		}

		public Boolean date_commandeIsNullable() {
			return false;
		}

		public Boolean date_commandeIsKey() {
			return false;
		}

		public Integer date_commandeLength() {
			return 19;
		}

		public Integer date_commandePrecision() {
			return 0;
		}

		public String date_commandeDefault() {

			return null;

		}

		public String date_commandeComment() {

			return "";

		}

		public String date_commandePattern() {

			return "dd/MM/yyyy HH:mm:ss";

		}

		public String date_commandeOriginalDbColumnName() {

			return "date_commande";

		}

		public int is_commande_annulee;

		public int getIs_commande_annulee() {
			return this.is_commande_annulee;
		}

		public Boolean is_commande_annuleeIsNullable() {
			return false;
		}

		public Boolean is_commande_annuleeIsKey() {
			return false;
		}

		public Integer is_commande_annuleeLength() {
			return 1;
		}

		public Integer is_commande_annuleePrecision() {
			return 0;
		}

		public String is_commande_annuleeDefault() {

			return "";

		}

		public String is_commande_annuleeComment() {

			return "";

		}

		public String is_commande_annuleePattern() {

			return "";

		}

		public String is_commande_annuleeOriginalDbColumnName() {

			return "is_commande_annulee";

		}

		public String nom_magasin;

		public String getNom_magasin() {
			return this.nom_magasin;
		}

		public Boolean nom_magasinIsNullable() {
			return false;
		}

		public Boolean nom_magasinIsKey() {
			return false;
		}

		public Integer nom_magasinLength() {
			return 255;
		}

		public Integer nom_magasinPrecision() {
			return 0;
		}

		public String nom_magasinDefault() {

			return null;

		}

		public String nom_magasinComment() {

			return "";

		}

		public String nom_magasinPattern() {

			return "";

		}

		public String nom_magasinOriginalDbColumnName() {

			return "nom_magasin";

		}

		public String pays_magasin;

		public String getPays_magasin() {
			return this.pays_magasin;
		}

		public Boolean pays_magasinIsNullable() {
			return false;
		}

		public Boolean pays_magasinIsKey() {
			return false;
		}

		public Integer pays_magasinLength() {
			return 255;
		}

		public Integer pays_magasinPrecision() {
			return 0;
		}

		public String pays_magasinDefault() {

			return null;

		}

		public String pays_magasinComment() {

			return "";

		}

		public String pays_magasinPattern() {

			return "";

		}

		public String pays_magasinOriginalDbColumnName() {

			return "pays_magasin";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.numero_commande;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final cde_filtreesStruct other = (cde_filtreesStruct) obj;

			if (this.numero_commande != other.numero_commande)
				return false;

			return true;
		}

		public void copyDataTo(cde_filtreesStruct other) {

			other.numero_commande = this.numero_commande;
			other.reference_produit = this.reference_produit;
			other.CONDITIONNEMENT = this.CONDITIONNEMENT;
			other.PRIX_UNITAIRE = this.PRIX_UNITAIRE;
			other.code_client = this.code_client;
			other.quantite = this.quantite;
			other.date_commande = this.date_commande;
			other.is_commande_annulee = this.is_commande_annulee;
			other.nom_magasin = this.nom_magasin;
			other.pays_magasin = this.pays_magasin;

		}

		public void copyKeysDataTo(cde_filtreesStruct other) {

			other.numero_commande = this.numero_commande;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TMC_GIT_Atlas_superstore_cde.length) {
					if (length < 1024 && commonByteArray_TMC_GIT_Atlas_superstore_cde.length == 0) {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[1024];
					} else {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length);
				strReturn = new String(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TMC_GIT_Atlas_superstore_cde.length) {
					if (length < 1024 && commonByteArray_TMC_GIT_Atlas_superstore_cde.length == 0) {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[1024];
					} else {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length);
				strReturn = new String(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TMC_GIT_Atlas_superstore_cde) {

				try {

					int length = 0;

					this.numero_commande = dis.readInt();

					this.reference_produit = readString(dis);

					this.CONDITIONNEMENT = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PRIX_UNITAIRE = null;
					} else {
						this.PRIX_UNITAIRE = dis.readFloat();
					}

					this.code_client = dis.readInt();

					this.quantite = dis.readInt();

					this.date_commande = readDate(dis);

					this.is_commande_annulee = dis.readInt();

					this.nom_magasin = readString(dis);

					this.pays_magasin = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_TMC_GIT_Atlas_superstore_cde) {

				try {

					int length = 0;

					this.numero_commande = dis.readInt();

					this.reference_produit = readString(dis);

					this.CONDITIONNEMENT = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PRIX_UNITAIRE = null;
					} else {
						this.PRIX_UNITAIRE = dis.readFloat();
					}

					this.code_client = dis.readInt();

					this.quantite = dis.readInt();

					this.date_commande = readDate(dis);

					this.is_commande_annulee = dis.readInt();

					this.nom_magasin = readString(dis);

					this.pays_magasin = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.numero_commande);

				// String

				writeString(this.reference_produit, dos);

				// Integer

				writeInteger(this.CONDITIONNEMENT, dos);

				// Float

				if (this.PRIX_UNITAIRE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.PRIX_UNITAIRE);
				}

				// int

				dos.writeInt(this.code_client);

				// int

				dos.writeInt(this.quantite);

				// java.util.Date

				writeDate(this.date_commande, dos);

				// int

				dos.writeInt(this.is_commande_annulee);

				// String

				writeString(this.nom_magasin, dos);

				// String

				writeString(this.pays_magasin, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.numero_commande);

				// String

				writeString(this.reference_produit, dos);

				// Integer

				writeInteger(this.CONDITIONNEMENT, dos);

				// Float

				if (this.PRIX_UNITAIRE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.PRIX_UNITAIRE);
				}

				// int

				dos.writeInt(this.code_client);

				// int

				dos.writeInt(this.quantite);

				// java.util.Date

				writeDate(this.date_commande, dos);

				// int

				dos.writeInt(this.is_commande_annulee);

				// String

				writeString(this.nom_magasin, dos);

				// String

				writeString(this.pays_magasin, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("numero_commande=" + String.valueOf(numero_commande));
			sb.append(",reference_produit=" + reference_produit);
			sb.append(",CONDITIONNEMENT=" + String.valueOf(CONDITIONNEMENT));
			sb.append(",PRIX_UNITAIRE=" + String.valueOf(PRIX_UNITAIRE));
			sb.append(",code_client=" + String.valueOf(code_client));
			sb.append(",quantite=" + String.valueOf(quantite));
			sb.append(",date_commande=" + String.valueOf(date_commande));
			sb.append(",is_commande_annulee=" + String.valueOf(is_commande_annulee));
			sb.append(",nom_magasin=" + nom_magasin);
			sb.append(",pays_magasin=" + pays_magasin);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(numero_commande);

			sb.append("|");

			if (reference_produit == null) {
				sb.append("<null>");
			} else {
				sb.append(reference_produit);
			}

			sb.append("|");

			if (CONDITIONNEMENT == null) {
				sb.append("<null>");
			} else {
				sb.append(CONDITIONNEMENT);
			}

			sb.append("|");

			if (PRIX_UNITAIRE == null) {
				sb.append("<null>");
			} else {
				sb.append(PRIX_UNITAIRE);
			}

			sb.append("|");

			sb.append(code_client);

			sb.append("|");

			sb.append(quantite);

			sb.append("|");

			if (date_commande == null) {
				sb.append("<null>");
			} else {
				sb.append(date_commande);
			}

			sb.append("|");

			sb.append(is_commande_annulee);

			sb.append("|");

			if (nom_magasin == null) {
				sb.append("<null>");
			} else {
				sb.append(nom_magasin);
			}

			sb.append("|");

			if (pays_magasin == null) {
				sb.append("<null>");
			} else {
				sb.append(pays_magasin);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(cde_filtreesStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.numero_commande, other.numero_commande);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class row1Struct implements routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock_TMC_GIT_Atlas_superstore_cde = new byte[0];
		static byte[] commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int numero_commande;

		public int getNumero_commande() {
			return this.numero_commande;
		}

		public Boolean numero_commandeIsNullable() {
			return false;
		}

		public Boolean numero_commandeIsKey() {
			return true;
		}

		public Integer numero_commandeLength() {
			return 11;
		}

		public Integer numero_commandePrecision() {
			return 0;
		}

		public String numero_commandeDefault() {

			return "";

		}

		public String numero_commandeComment() {

			return "";

		}

		public String numero_commandePattern() {

			return "";

		}

		public String numero_commandeOriginalDbColumnName() {

			return "numero_commande";

		}

		public String reference_produit;

		public String getReference_produit() {
			return this.reference_produit;
		}

		public Boolean reference_produitIsNullable() {
			return false;
		}

		public Boolean reference_produitIsKey() {
			return false;
		}

		public Integer reference_produitLength() {
			return 50;
		}

		public Integer reference_produitPrecision() {
			return 0;
		}

		public String reference_produitDefault() {

			return null;

		}

		public String reference_produitComment() {

			return "";

		}

		public String reference_produitPattern() {

			return "";

		}

		public String reference_produitOriginalDbColumnName() {

			return "reference_produit";

		}

		public Integer CONDITIONNEMENT;

		public Integer getCONDITIONNEMENT() {
			return this.CONDITIONNEMENT;
		}

		public Boolean CONDITIONNEMENTIsNullable() {
			return true;
		}

		public Boolean CONDITIONNEMENTIsKey() {
			return false;
		}

		public Integer CONDITIONNEMENTLength() {
			return null;
		}

		public Integer CONDITIONNEMENTPrecision() {
			return null;
		}

		public String CONDITIONNEMENTDefault() {

			return null;

		}

		public String CONDITIONNEMENTComment() {

			return "";

		}

		public String CONDITIONNEMENTPattern() {

			return "";

		}

		public String CONDITIONNEMENTOriginalDbColumnName() {

			return "CONDITIONNEMENT";

		}

		public Float PRIX_UNITAIRE;

		public Float getPRIX_UNITAIRE() {
			return this.PRIX_UNITAIRE;
		}

		public Boolean PRIX_UNITAIREIsNullable() {
			return true;
		}

		public Boolean PRIX_UNITAIREIsKey() {
			return false;
		}

		public Integer PRIX_UNITAIRELength() {
			return null;
		}

		public Integer PRIX_UNITAIREPrecision() {
			return null;
		}

		public String PRIX_UNITAIREDefault() {

			return null;

		}

		public String PRIX_UNITAIREComment() {

			return "";

		}

		public String PRIX_UNITAIREPattern() {

			return "";

		}

		public String PRIX_UNITAIREOriginalDbColumnName() {

			return "PRIX_UNITAIRE";

		}

		public int code_client;

		public int getCode_client() {
			return this.code_client;
		}

		public Boolean code_clientIsNullable() {
			return false;
		}

		public Boolean code_clientIsKey() {
			return false;
		}

		public Integer code_clientLength() {
			return 11;
		}

		public Integer code_clientPrecision() {
			return 0;
		}

		public String code_clientDefault() {

			return "";

		}

		public String code_clientComment() {

			return "";

		}

		public String code_clientPattern() {

			return "";

		}

		public String code_clientOriginalDbColumnName() {

			return "code_client";

		}

		public int quantite;

		public int getQuantite() {
			return this.quantite;
		}

		public Boolean quantiteIsNullable() {
			return false;
		}

		public Boolean quantiteIsKey() {
			return false;
		}

		public Integer quantiteLength() {
			return 11;
		}

		public Integer quantitePrecision() {
			return 0;
		}

		public String quantiteDefault() {

			return "";

		}

		public String quantiteComment() {

			return "";

		}

		public String quantitePattern() {

			return "";

		}

		public String quantiteOriginalDbColumnName() {

			return "quantite";

		}

		public java.util.Date date_commande;

		public java.util.Date getDate_commande() {
			return this.date_commande;
		}

		public Boolean date_commandeIsNullable() {
			return false;
		}

		public Boolean date_commandeIsKey() {
			return false;
		}

		public Integer date_commandeLength() {
			return 19;
		}

		public Integer date_commandePrecision() {
			return 0;
		}

		public String date_commandeDefault() {

			return null;

		}

		public String date_commandeComment() {

			return "";

		}

		public String date_commandePattern() {

			return "dd/MM/yyyy HH:mm:ss";

		}

		public String date_commandeOriginalDbColumnName() {

			return "date_commande";

		}

		public int is_commande_annulee;

		public int getIs_commande_annulee() {
			return this.is_commande_annulee;
		}

		public Boolean is_commande_annuleeIsNullable() {
			return false;
		}

		public Boolean is_commande_annuleeIsKey() {
			return false;
		}

		public Integer is_commande_annuleeLength() {
			return 1;
		}

		public Integer is_commande_annuleePrecision() {
			return 0;
		}

		public String is_commande_annuleeDefault() {

			return "";

		}

		public String is_commande_annuleeComment() {

			return "";

		}

		public String is_commande_annuleePattern() {

			return "";

		}

		public String is_commande_annuleeOriginalDbColumnName() {

			return "is_commande_annulee";

		}

		public String nom_magasin;

		public String getNom_magasin() {
			return this.nom_magasin;
		}

		public Boolean nom_magasinIsNullable() {
			return false;
		}

		public Boolean nom_magasinIsKey() {
			return false;
		}

		public Integer nom_magasinLength() {
			return 255;
		}

		public Integer nom_magasinPrecision() {
			return 0;
		}

		public String nom_magasinDefault() {

			return null;

		}

		public String nom_magasinComment() {

			return "";

		}

		public String nom_magasinPattern() {

			return "";

		}

		public String nom_magasinOriginalDbColumnName() {

			return "nom_magasin";

		}

		public String pays_magasin;

		public String getPays_magasin() {
			return this.pays_magasin;
		}

		public Boolean pays_magasinIsNullable() {
			return false;
		}

		public Boolean pays_magasinIsKey() {
			return false;
		}

		public Integer pays_magasinLength() {
			return 255;
		}

		public Integer pays_magasinPrecision() {
			return 0;
		}

		public String pays_magasinDefault() {

			return null;

		}

		public String pays_magasinComment() {

			return "";

		}

		public String pays_magasinPattern() {

			return "";

		}

		public String pays_magasinOriginalDbColumnName() {

			return "pays_magasin";

		}

		public String errorMessage;

		public String getErrorMessage() {
			return this.errorMessage;
		}

		public Boolean errorMessageIsNullable() {
			return true;
		}

		public Boolean errorMessageIsKey() {
			return false;
		}

		public Integer errorMessageLength() {
			return 255;
		}

		public Integer errorMessagePrecision() {
			return 0;
		}

		public String errorMessageDefault() {

			return "";

		}

		public String errorMessageComment() {

			return null;

		}

		public String errorMessagePattern() {

			return null;

		}

		public String errorMessageOriginalDbColumnName() {

			return "errorMessage";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.numero_commande;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final row1Struct other = (row1Struct) obj;

			if (this.numero_commande != other.numero_commande)
				return false;

			return true;
		}

		public void copyDataTo(row1Struct other) {

			other.numero_commande = this.numero_commande;
			other.reference_produit = this.reference_produit;
			other.CONDITIONNEMENT = this.CONDITIONNEMENT;
			other.PRIX_UNITAIRE = this.PRIX_UNITAIRE;
			other.code_client = this.code_client;
			other.quantite = this.quantite;
			other.date_commande = this.date_commande;
			other.is_commande_annulee = this.is_commande_annulee;
			other.nom_magasin = this.nom_magasin;
			other.pays_magasin = this.pays_magasin;
			other.errorMessage = this.errorMessage;

		}

		public void copyKeysDataTo(row1Struct other) {

			other.numero_commande = this.numero_commande;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TMC_GIT_Atlas_superstore_cde.length) {
					if (length < 1024 && commonByteArray_TMC_GIT_Atlas_superstore_cde.length == 0) {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[1024];
					} else {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length);
				strReturn = new String(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TMC_GIT_Atlas_superstore_cde.length) {
					if (length < 1024 && commonByteArray_TMC_GIT_Atlas_superstore_cde.length == 0) {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[1024];
					} else {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length);
				strReturn = new String(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TMC_GIT_Atlas_superstore_cde) {

				try {

					int length = 0;

					this.numero_commande = dis.readInt();

					this.reference_produit = readString(dis);

					this.CONDITIONNEMENT = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PRIX_UNITAIRE = null;
					} else {
						this.PRIX_UNITAIRE = dis.readFloat();
					}

					this.code_client = dis.readInt();

					this.quantite = dis.readInt();

					this.date_commande = readDate(dis);

					this.is_commande_annulee = dis.readInt();

					this.nom_magasin = readString(dis);

					this.pays_magasin = readString(dis);

					this.errorMessage = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_TMC_GIT_Atlas_superstore_cde) {

				try {

					int length = 0;

					this.numero_commande = dis.readInt();

					this.reference_produit = readString(dis);

					this.CONDITIONNEMENT = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PRIX_UNITAIRE = null;
					} else {
						this.PRIX_UNITAIRE = dis.readFloat();
					}

					this.code_client = dis.readInt();

					this.quantite = dis.readInt();

					this.date_commande = readDate(dis);

					this.is_commande_annulee = dis.readInt();

					this.nom_magasin = readString(dis);

					this.pays_magasin = readString(dis);

					this.errorMessage = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.numero_commande);

				// String

				writeString(this.reference_produit, dos);

				// Integer

				writeInteger(this.CONDITIONNEMENT, dos);

				// Float

				if (this.PRIX_UNITAIRE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.PRIX_UNITAIRE);
				}

				// int

				dos.writeInt(this.code_client);

				// int

				dos.writeInt(this.quantite);

				// java.util.Date

				writeDate(this.date_commande, dos);

				// int

				dos.writeInt(this.is_commande_annulee);

				// String

				writeString(this.nom_magasin, dos);

				// String

				writeString(this.pays_magasin, dos);

				// String

				writeString(this.errorMessage, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.numero_commande);

				// String

				writeString(this.reference_produit, dos);

				// Integer

				writeInteger(this.CONDITIONNEMENT, dos);

				// Float

				if (this.PRIX_UNITAIRE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.PRIX_UNITAIRE);
				}

				// int

				dos.writeInt(this.code_client);

				// int

				dos.writeInt(this.quantite);

				// java.util.Date

				writeDate(this.date_commande, dos);

				// int

				dos.writeInt(this.is_commande_annulee);

				// String

				writeString(this.nom_magasin, dos);

				// String

				writeString(this.pays_magasin, dos);

				// String

				writeString(this.errorMessage, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("numero_commande=" + String.valueOf(numero_commande));
			sb.append(",reference_produit=" + reference_produit);
			sb.append(",CONDITIONNEMENT=" + String.valueOf(CONDITIONNEMENT));
			sb.append(",PRIX_UNITAIRE=" + String.valueOf(PRIX_UNITAIRE));
			sb.append(",code_client=" + String.valueOf(code_client));
			sb.append(",quantite=" + String.valueOf(quantite));
			sb.append(",date_commande=" + String.valueOf(date_commande));
			sb.append(",is_commande_annulee=" + String.valueOf(is_commande_annulee));
			sb.append(",nom_magasin=" + nom_magasin);
			sb.append(",pays_magasin=" + pays_magasin);
			sb.append(",errorMessage=" + errorMessage);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(numero_commande);

			sb.append("|");

			if (reference_produit == null) {
				sb.append("<null>");
			} else {
				sb.append(reference_produit);
			}

			sb.append("|");

			if (CONDITIONNEMENT == null) {
				sb.append("<null>");
			} else {
				sb.append(CONDITIONNEMENT);
			}

			sb.append("|");

			if (PRIX_UNITAIRE == null) {
				sb.append("<null>");
			} else {
				sb.append(PRIX_UNITAIRE);
			}

			sb.append("|");

			sb.append(code_client);

			sb.append("|");

			sb.append(quantite);

			sb.append("|");

			if (date_commande == null) {
				sb.append("<null>");
			} else {
				sb.append(date_commande);
			}

			sb.append("|");

			sb.append(is_commande_annulee);

			sb.append("|");

			if (nom_magasin == null) {
				sb.append("<null>");
			} else {
				sb.append(nom_magasin);
			}

			sb.append("|");

			if (pays_magasin == null) {
				sb.append("<null>");
			} else {
				sb.append(pays_magasin);
			}

			sb.append("|");

			if (errorMessage == null) {
				sb.append("<null>");
			} else {
				sb.append(errorMessage);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.numero_commande, other.numero_commande);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class CleanedStruct implements routines.system.IPersistableRow<CleanedStruct> {
		final static byte[] commonByteArrayLock_TMC_GIT_Atlas_superstore_cde = new byte[0];
		static byte[] commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int numero_commande;

		public int getNumero_commande() {
			return this.numero_commande;
		}

		public Boolean numero_commandeIsNullable() {
			return false;
		}

		public Boolean numero_commandeIsKey() {
			return true;
		}

		public Integer numero_commandeLength() {
			return 11;
		}

		public Integer numero_commandePrecision() {
			return 0;
		}

		public String numero_commandeDefault() {

			return "";

		}

		public String numero_commandeComment() {

			return "";

		}

		public String numero_commandePattern() {

			return "";

		}

		public String numero_commandeOriginalDbColumnName() {

			return "numero_commande";

		}

		public String reference_produit;

		public String getReference_produit() {
			return this.reference_produit;
		}

		public Boolean reference_produitIsNullable() {
			return false;
		}

		public Boolean reference_produitIsKey() {
			return false;
		}

		public Integer reference_produitLength() {
			return 50;
		}

		public Integer reference_produitPrecision() {
			return 0;
		}

		public String reference_produitDefault() {

			return null;

		}

		public String reference_produitComment() {

			return "";

		}

		public String reference_produitPattern() {

			return "";

		}

		public String reference_produitOriginalDbColumnName() {

			return "reference_produit";

		}

		public Integer CONDITIONNEMENT;

		public Integer getCONDITIONNEMENT() {
			return this.CONDITIONNEMENT;
		}

		public Boolean CONDITIONNEMENTIsNullable() {
			return true;
		}

		public Boolean CONDITIONNEMENTIsKey() {
			return false;
		}

		public Integer CONDITIONNEMENTLength() {
			return null;
		}

		public Integer CONDITIONNEMENTPrecision() {
			return null;
		}

		public String CONDITIONNEMENTDefault() {

			return null;

		}

		public String CONDITIONNEMENTComment() {

			return "";

		}

		public String CONDITIONNEMENTPattern() {

			return "";

		}

		public String CONDITIONNEMENTOriginalDbColumnName() {

			return "CONDITIONNEMENT";

		}

		public Float PRIX_UNITAIRE;

		public Float getPRIX_UNITAIRE() {
			return this.PRIX_UNITAIRE;
		}

		public Boolean PRIX_UNITAIREIsNullable() {
			return true;
		}

		public Boolean PRIX_UNITAIREIsKey() {
			return false;
		}

		public Integer PRIX_UNITAIRELength() {
			return null;
		}

		public Integer PRIX_UNITAIREPrecision() {
			return null;
		}

		public String PRIX_UNITAIREDefault() {

			return null;

		}

		public String PRIX_UNITAIREComment() {

			return "";

		}

		public String PRIX_UNITAIREPattern() {

			return "";

		}

		public String PRIX_UNITAIREOriginalDbColumnName() {

			return "PRIX_UNITAIRE";

		}

		public int code_client;

		public int getCode_client() {
			return this.code_client;
		}

		public Boolean code_clientIsNullable() {
			return false;
		}

		public Boolean code_clientIsKey() {
			return false;
		}

		public Integer code_clientLength() {
			return 11;
		}

		public Integer code_clientPrecision() {
			return 0;
		}

		public String code_clientDefault() {

			return "";

		}

		public String code_clientComment() {

			return "";

		}

		public String code_clientPattern() {

			return "";

		}

		public String code_clientOriginalDbColumnName() {

			return "code_client";

		}

		public int quantite;

		public int getQuantite() {
			return this.quantite;
		}

		public Boolean quantiteIsNullable() {
			return false;
		}

		public Boolean quantiteIsKey() {
			return false;
		}

		public Integer quantiteLength() {
			return 11;
		}

		public Integer quantitePrecision() {
			return 0;
		}

		public String quantiteDefault() {

			return "";

		}

		public String quantiteComment() {

			return "";

		}

		public String quantitePattern() {

			return "";

		}

		public String quantiteOriginalDbColumnName() {

			return "quantite";

		}

		public java.util.Date date_commande;

		public java.util.Date getDate_commande() {
			return this.date_commande;
		}

		public Boolean date_commandeIsNullable() {
			return false;
		}

		public Boolean date_commandeIsKey() {
			return false;
		}

		public Integer date_commandeLength() {
			return 19;
		}

		public Integer date_commandePrecision() {
			return 0;
		}

		public String date_commandeDefault() {

			return null;

		}

		public String date_commandeComment() {

			return "";

		}

		public String date_commandePattern() {

			return "dd/MM/yyyy HH:mm:ss";

		}

		public String date_commandeOriginalDbColumnName() {

			return "date_commande";

		}

		public int is_commande_annulee;

		public int getIs_commande_annulee() {
			return this.is_commande_annulee;
		}

		public Boolean is_commande_annuleeIsNullable() {
			return false;
		}

		public Boolean is_commande_annuleeIsKey() {
			return false;
		}

		public Integer is_commande_annuleeLength() {
			return 1;
		}

		public Integer is_commande_annuleePrecision() {
			return 0;
		}

		public String is_commande_annuleeDefault() {

			return "";

		}

		public String is_commande_annuleeComment() {

			return "";

		}

		public String is_commande_annuleePattern() {

			return "";

		}

		public String is_commande_annuleeOriginalDbColumnName() {

			return "is_commande_annulee";

		}

		public String nom_magasin;

		public String getNom_magasin() {
			return this.nom_magasin;
		}

		public Boolean nom_magasinIsNullable() {
			return false;
		}

		public Boolean nom_magasinIsKey() {
			return false;
		}

		public Integer nom_magasinLength() {
			return 255;
		}

		public Integer nom_magasinPrecision() {
			return 0;
		}

		public String nom_magasinDefault() {

			return null;

		}

		public String nom_magasinComment() {

			return "";

		}

		public String nom_magasinPattern() {

			return "";

		}

		public String nom_magasinOriginalDbColumnName() {

			return "nom_magasin";

		}

		public String pays_magasin;

		public String getPays_magasin() {
			return this.pays_magasin;
		}

		public Boolean pays_magasinIsNullable() {
			return false;
		}

		public Boolean pays_magasinIsKey() {
			return false;
		}

		public Integer pays_magasinLength() {
			return 255;
		}

		public Integer pays_magasinPrecision() {
			return 0;
		}

		public String pays_magasinDefault() {

			return null;

		}

		public String pays_magasinComment() {

			return "";

		}

		public String pays_magasinPattern() {

			return "";

		}

		public String pays_magasinOriginalDbColumnName() {

			return "pays_magasin";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.numero_commande;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final CleanedStruct other = (CleanedStruct) obj;

			if (this.numero_commande != other.numero_commande)
				return false;

			return true;
		}

		public void copyDataTo(CleanedStruct other) {

			other.numero_commande = this.numero_commande;
			other.reference_produit = this.reference_produit;
			other.CONDITIONNEMENT = this.CONDITIONNEMENT;
			other.PRIX_UNITAIRE = this.PRIX_UNITAIRE;
			other.code_client = this.code_client;
			other.quantite = this.quantite;
			other.date_commande = this.date_commande;
			other.is_commande_annulee = this.is_commande_annulee;
			other.nom_magasin = this.nom_magasin;
			other.pays_magasin = this.pays_magasin;

		}

		public void copyKeysDataTo(CleanedStruct other) {

			other.numero_commande = this.numero_commande;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TMC_GIT_Atlas_superstore_cde.length) {
					if (length < 1024 && commonByteArray_TMC_GIT_Atlas_superstore_cde.length == 0) {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[1024];
					} else {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length);
				strReturn = new String(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TMC_GIT_Atlas_superstore_cde.length) {
					if (length < 1024 && commonByteArray_TMC_GIT_Atlas_superstore_cde.length == 0) {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[1024];
					} else {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length);
				strReturn = new String(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private java.util.Date readDate(ObjectInputStream dis) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TMC_GIT_Atlas_superstore_cde) {

				try {

					int length = 0;

					this.numero_commande = dis.readInt();

					this.reference_produit = readString(dis);

					this.CONDITIONNEMENT = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PRIX_UNITAIRE = null;
					} else {
						this.PRIX_UNITAIRE = dis.readFloat();
					}

					this.code_client = dis.readInt();

					this.quantite = dis.readInt();

					this.date_commande = readDate(dis);

					this.is_commande_annulee = dis.readInt();

					this.nom_magasin = readString(dis);

					this.pays_magasin = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_TMC_GIT_Atlas_superstore_cde) {

				try {

					int length = 0;

					this.numero_commande = dis.readInt();

					this.reference_produit = readString(dis);

					this.CONDITIONNEMENT = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PRIX_UNITAIRE = null;
					} else {
						this.PRIX_UNITAIRE = dis.readFloat();
					}

					this.code_client = dis.readInt();

					this.quantite = dis.readInt();

					this.date_commande = readDate(dis);

					this.is_commande_annulee = dis.readInt();

					this.nom_magasin = readString(dis);

					this.pays_magasin = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.numero_commande);

				// String

				writeString(this.reference_produit, dos);

				// Integer

				writeInteger(this.CONDITIONNEMENT, dos);

				// Float

				if (this.PRIX_UNITAIRE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.PRIX_UNITAIRE);
				}

				// int

				dos.writeInt(this.code_client);

				// int

				dos.writeInt(this.quantite);

				// java.util.Date

				writeDate(this.date_commande, dos);

				// int

				dos.writeInt(this.is_commande_annulee);

				// String

				writeString(this.nom_magasin, dos);

				// String

				writeString(this.pays_magasin, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.numero_commande);

				// String

				writeString(this.reference_produit, dos);

				// Integer

				writeInteger(this.CONDITIONNEMENT, dos);

				// Float

				if (this.PRIX_UNITAIRE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.PRIX_UNITAIRE);
				}

				// int

				dos.writeInt(this.code_client);

				// int

				dos.writeInt(this.quantite);

				// java.util.Date

				writeDate(this.date_commande, dos);

				// int

				dos.writeInt(this.is_commande_annulee);

				// String

				writeString(this.nom_magasin, dos);

				// String

				writeString(this.pays_magasin, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("numero_commande=" + String.valueOf(numero_commande));
			sb.append(",reference_produit=" + reference_produit);
			sb.append(",CONDITIONNEMENT=" + String.valueOf(CONDITIONNEMENT));
			sb.append(",PRIX_UNITAIRE=" + String.valueOf(PRIX_UNITAIRE));
			sb.append(",code_client=" + String.valueOf(code_client));
			sb.append(",quantite=" + String.valueOf(quantite));
			sb.append(",date_commande=" + String.valueOf(date_commande));
			sb.append(",is_commande_annulee=" + String.valueOf(is_commande_annulee));
			sb.append(",nom_magasin=" + nom_magasin);
			sb.append(",pays_magasin=" + pays_magasin);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(numero_commande);

			sb.append("|");

			if (reference_produit == null) {
				sb.append("<null>");
			} else {
				sb.append(reference_produit);
			}

			sb.append("|");

			if (CONDITIONNEMENT == null) {
				sb.append("<null>");
			} else {
				sb.append(CONDITIONNEMENT);
			}

			sb.append("|");

			if (PRIX_UNITAIRE == null) {
				sb.append("<null>");
			} else {
				sb.append(PRIX_UNITAIRE);
			}

			sb.append("|");

			sb.append(code_client);

			sb.append("|");

			sb.append(quantite);

			sb.append("|");

			if (date_commande == null) {
				sb.append("<null>");
			} else {
				sb.append(date_commande);
			}

			sb.append("|");

			sb.append(is_commande_annulee);

			sb.append("|");

			if (nom_magasin == null) {
				sb.append("<null>");
			} else {
				sb.append(nom_magasin);
			}

			sb.append("|");

			if (pays_magasin == null) {
				sb.append("<null>");
			} else {
				sb.append(pays_magasin);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(CleanedStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.numero_commande, other.numero_commande);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class cdeStruct implements routines.system.IPersistableRow<cdeStruct> {
		final static byte[] commonByteArrayLock_TMC_GIT_Atlas_superstore_cde = new byte[0];
		static byte[] commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[0];

		public String REFERENCE;

		public String getREFERENCE() {
			return this.REFERENCE;
		}

		public Boolean REFERENCEIsNullable() {
			return false;
		}

		public Boolean REFERENCEIsKey() {
			return true;
		}

		public Integer REFERENCELength() {
			return null;
		}

		public Integer REFERENCEPrecision() {
			return null;
		}

		public String REFERENCEDefault() {

			return null;

		}

		public String REFERENCEComment() {

			return "";

		}

		public String REFERENCEPattern() {

			return "";

		}

		public String REFERENCEOriginalDbColumnName() {

			return "REFERENCE";

		}

		public Integer CONDITIONNEMENT;

		public Integer getCONDITIONNEMENT() {
			return this.CONDITIONNEMENT;
		}

		public Boolean CONDITIONNEMENTIsNullable() {
			return true;
		}

		public Boolean CONDITIONNEMENTIsKey() {
			return false;
		}

		public Integer CONDITIONNEMENTLength() {
			return null;
		}

		public Integer CONDITIONNEMENTPrecision() {
			return null;
		}

		public String CONDITIONNEMENTDefault() {

			return null;

		}

		public String CONDITIONNEMENTComment() {

			return "";

		}

		public String CONDITIONNEMENTPattern() {

			return "";

		}

		public String CONDITIONNEMENTOriginalDbColumnName() {

			return "CONDITIONNEMENT";

		}

		public Float PRIX_UNITAIRE;

		public Float getPRIX_UNITAIRE() {
			return this.PRIX_UNITAIRE;
		}

		public Boolean PRIX_UNITAIREIsNullable() {
			return true;
		}

		public Boolean PRIX_UNITAIREIsKey() {
			return false;
		}

		public Integer PRIX_UNITAIRELength() {
			return null;
		}

		public Integer PRIX_UNITAIREPrecision() {
			return null;
		}

		public String PRIX_UNITAIREDefault() {

			return null;

		}

		public String PRIX_UNITAIREComment() {

			return "";

		}

		public String PRIX_UNITAIREPattern() {

			return "";

		}

		public String PRIX_UNITAIREOriginalDbColumnName() {

			return "PRIX_UNITAIRE";

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TMC_GIT_Atlas_superstore_cde.length) {
					if (length < 1024 && commonByteArray_TMC_GIT_Atlas_superstore_cde.length == 0) {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[1024];
					} else {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length);
				strReturn = new String(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TMC_GIT_Atlas_superstore_cde.length) {
					if (length < 1024 && commonByteArray_TMC_GIT_Atlas_superstore_cde.length == 0) {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[1024];
					} else {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length);
				strReturn = new String(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TMC_GIT_Atlas_superstore_cde) {

				try {

					int length = 0;

					this.REFERENCE = readString(dis);

					this.CONDITIONNEMENT = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PRIX_UNITAIRE = null;
					} else {
						this.PRIX_UNITAIRE = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_TMC_GIT_Atlas_superstore_cde) {

				try {

					int length = 0;

					this.REFERENCE = readString(dis);

					this.CONDITIONNEMENT = readInteger(dis);

					length = dis.readByte();
					if (length == -1) {
						this.PRIX_UNITAIRE = null;
					} else {
						this.PRIX_UNITAIRE = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.REFERENCE, dos);

				// Integer

				writeInteger(this.CONDITIONNEMENT, dos);

				// Float

				if (this.PRIX_UNITAIRE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.PRIX_UNITAIRE);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.REFERENCE, dos);

				// Integer

				writeInteger(this.CONDITIONNEMENT, dos);

				// Float

				if (this.PRIX_UNITAIRE == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.PRIX_UNITAIRE);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("REFERENCE=" + REFERENCE);
			sb.append(",CONDITIONNEMENT=" + String.valueOf(CONDITIONNEMENT));
			sb.append(",PRIX_UNITAIRE=" + String.valueOf(PRIX_UNITAIRE));
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			if (REFERENCE == null) {
				sb.append("<null>");
			} else {
				sb.append(REFERENCE);
			}

			sb.append("|");

			if (CONDITIONNEMENT == null) {
				sb.append("<null>");
			} else {
				sb.append(CONDITIONNEMENT);
			}

			sb.append("|");

			if (PRIX_UNITAIRE == null) {
				sb.append("<null>");
			} else {
				sb.append(PRIX_UNITAIRE);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(cdeStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tFileInputDelimited_1");
		org.slf4j.MDC.put("_subJobPid", "nBB2BF_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				cdeStruct cde = new cdeStruct();
				CleanedStruct Cleaned = new CleanedStruct();
				cde_filtreesStruct cde_filtrees = new cde_filtreesStruct();
				cde_filtreesStruct cde_cleaned = cde_filtrees;
				row1Struct row1 = new row1Struct();

				/**
				 * [tDBOutput_1 begin ] start
				 */

				ok_Hash.put("tDBOutput_1", false);
				start_Hash.put("tDBOutput_1", System.currentTimeMillis());

				currentComponent = "tDBOutput_1";

				cLabel = "sortie_stg";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "cde_cleaned");

				int tos_count_tDBOutput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBOutput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBOutput_1 = new StringBuilder();
							log4jParamters_tDBOutput_1.append("Parameters:");
							log4jParamters_tDBOutput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("CONNECTION" + " = " + "tDBConnection_1");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE" + " = " + "\"stg_atlas_superstore_commandes\"");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("TABLE_ACTION" + " = " + "DROP_IF_EXISTS_AND_CREATE");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DATA_ACTION" + " = " + "UPDATE_OR_INSERT");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("DIE_ON_ERROR" + " = " + "true");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ADD_COLS" + " = " + "[]");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_FIELD_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("USE_HINT_OPTIONS" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("ENABLE_DEBUG_MODE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("SUPPORT_NULL_WHERE" + " = " + "false");
							log4jParamters_tDBOutput_1.append(" | ");
							log4jParamters_tDBOutput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlOutput");
							log4jParamters_tDBOutput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBOutput_1 - " + (log4jParamters_tDBOutput_1));
						}
					}
					new BytesLimit65535_tDBOutput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBOutput_1", "sortie_stg", "tMysqlOutput");
					talendJobLogProcess(globalMap);
				}

				int updateKeyCount_tDBOutput_1 = 1;
				if (updateKeyCount_tDBOutput_1 < 1) {
					throw new RuntimeException("For update, Schema must have a key");
				} else if (updateKeyCount_tDBOutput_1 == 10 && true) {
					log.warn("For update, every Schema column can not be a key");
				}

				int nb_line_tDBOutput_1 = 0;
				int nb_line_update_tDBOutput_1 = 0;
				int nb_line_inserted_tDBOutput_1 = 0;
				int nb_line_deleted_tDBOutput_1 = 0;
				int nb_line_rejected_tDBOutput_1 = 0;

				int deletedCount_tDBOutput_1 = 0;
				int updatedCount_tDBOutput_1 = 0;
				int insertedCount_tDBOutput_1 = 0;
				int rowsToCommitCount_tDBOutput_1 = 0;
				int rejectedCount_tDBOutput_1 = 0;

				String tableName_tDBOutput_1 = "stg_atlas_superstore_commandes";
				boolean whetherReject_tDBOutput_1 = false;

				java.util.Calendar calendar_tDBOutput_1 = java.util.Calendar.getInstance();
				calendar_tDBOutput_1.set(1, 0, 1, 0, 0, 0);
				long year1_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
				calendar_tDBOutput_1.set(10000, 0, 1, 0, 0, 0);
				long year10000_tDBOutput_1 = calendar_tDBOutput_1.getTime().getTime();
				long date_tDBOutput_1;

				java.sql.Connection conn_tDBOutput_1 = null;
				conn_tDBOutput_1 = (java.sql.Connection) globalMap.get("conn_tDBConnection_1");

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Uses an existing connection with username '")
							+ (conn_tDBOutput_1.getMetaData().getUserName()) + ("'. Connection URL: ")
							+ (conn_tDBOutput_1.getMetaData().getURL()) + ("."));

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Connection is set auto commit to '")
							+ (conn_tDBOutput_1.getAutoCommit()) + ("'."));

				int count_tDBOutput_1 = 0;

				java.sql.DatabaseMetaData dbMetaData_tDBOutput_1 = conn_tDBOutput_1.getMetaData();
				java.sql.ResultSet rsTable_tDBOutput_1 = dbMetaData_tDBOutput_1.getTables("atlas_superstore", null,
						null, new String[] { "TABLE" });
				boolean whetherExist_tDBOutput_1 = false;
				while (rsTable_tDBOutput_1.next()) {
					String table_tDBOutput_1 = rsTable_tDBOutput_1.getString("TABLE_NAME");
					if (table_tDBOutput_1.equalsIgnoreCase("stg_atlas_superstore_commandes")) {
						whetherExist_tDBOutput_1 = true;
						break;
					}
				}
				if (whetherExist_tDBOutput_1) {
					try (java.sql.Statement stmtDrop_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
						if (log.isDebugEnabled())
							log.debug(
									"tDBOutput_1 - " + ("Dropping") + (" table '") + (tableName_tDBOutput_1) + ("'."));
						stmtDrop_tDBOutput_1.execute("DROP TABLE `" + tableName_tDBOutput_1 + "`");
						if (log.isDebugEnabled())
							log.debug("tDBOutput_1 - " + ("Drop") + (" table '") + (tableName_tDBOutput_1)
									+ ("' has succeeded."));
					}
				}
				try (java.sql.Statement stmtCreate_tDBOutput_1 = conn_tDBOutput_1.createStatement()) {
					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Creating") + (" table '") + (tableName_tDBOutput_1) + ("'."));
					stmtCreate_tDBOutput_1.execute("CREATE TABLE `" + tableName_tDBOutput_1
							+ "`(`numero_commande` INT(11)   not null ,`reference_produit` VARCHAR(50)   not null ,`CONDITIONNEMENT` INT(0)  ,`PRIX_UNITAIRE` FLOAT ,`code_client` INT(11)   not null ,`quantite` INT(11)   not null ,`date_commande` DATETIME  not null ,`is_commande_annulee` INT(1)   not null ,`nom_magasin` VARCHAR(255)   not null ,`pays_magasin` VARCHAR(255)   not null ,primary key(`numero_commande`))");
					if (log.isDebugEnabled())
						log.debug("tDBOutput_1 - " + ("Create") + (" table '") + (tableName_tDBOutput_1)
								+ ("' has succeeded."));
				}

				String update_tDBOutput_1 = "UPDATE `" + "stg_atlas_superstore_commandes"
						+ "` SET `reference_produit` = ?,`CONDITIONNEMENT` = ?,`PRIX_UNITAIRE` = ?,`code_client` = ?,`quantite` = ?,`date_commande` = ?,`is_commande_annulee` = ?,`nom_magasin` = ?,`pays_magasin` = ? WHERE `numero_commande` = ?";

				java.sql.PreparedStatement pstmtUpdate_tDBOutput_1 = conn_tDBOutput_1
						.prepareStatement(update_tDBOutput_1);
				resourceMap.put("pstmtUpdate_tDBOutput_1", pstmtUpdate_tDBOutput_1);
				String insert_tDBOutput_1 = "INSERT INTO `" + "stg_atlas_superstore_commandes"
						+ "` (`numero_commande`,`reference_produit`,`CONDITIONNEMENT`,`PRIX_UNITAIRE`,`code_client`,`quantite`,`date_commande`,`is_commande_annulee`,`nom_magasin`,`pays_magasin`) VALUES (?,?,?,?,?,?,?,?,?,?)";

				java.sql.PreparedStatement pstmtInsert_tDBOutput_1 = conn_tDBOutput_1
						.prepareStatement(insert_tDBOutput_1);
				resourceMap.put("pstmtInsert_tDBOutput_1", pstmtInsert_tDBOutput_1);

				/**
				 * [tDBOutput_1 begin ] stop
				 */

				/**
				 * [tLogRow_1 begin ] start
				 */

				ok_Hash.put("tLogRow_1", false);
				start_Hash.put("tLogRow_1", System.currentTimeMillis());

				currentComponent = "tLogRow_1";

				cLabel = "data_client_clean";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "cde_filtrees");

				int tos_count_tLogRow_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tLogRow_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tLogRow_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tLogRow_1 = new StringBuilder();
							log4jParamters_tLogRow_1.append("Parameters:");
							log4jParamters_tLogRow_1.append("BASIC_MODE" + " = " + "false");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("TABLE_PRINT" + " = " + "true");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("VERTICAL" + " = " + "false");
							log4jParamters_tLogRow_1.append(" | ");
							log4jParamters_tLogRow_1.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
							log4jParamters_tLogRow_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tLogRow_1 - " + (log4jParamters_tLogRow_1));
						}
					}
					new BytesLimit65535_tLogRow_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tLogRow_1", "data_client_clean", "tLogRow");
					talendJobLogProcess(globalMap);
				}

				///////////////////////

				class Util_tLogRow_1 {

					String[] des_top = { ".", ".", "-", "+" };

					String[] des_head = { "|=", "=|", "-", "+" };

					String[] des_bottom = { "'", "'", "-", "+" };

					String name = "";

					java.util.List<String[]> list = new java.util.ArrayList<String[]>();

					int[] colLengths = new int[10];

					public void addRow(String[] row) {

						for (int i = 0; i < 10; i++) {
							if (row[i] != null) {
								colLengths[i] = Math.max(colLengths[i], row[i].length());
							}
						}
						list.add(row);
					}

					public void setTableName(String name) {

						this.name = name;
					}

					public StringBuilder format() {

						StringBuilder sb = new StringBuilder();

						sb.append(print(des_top));

						int totals = 0;
						for (int i = 0; i < colLengths.length; i++) {
							totals = totals + colLengths[i];
						}

						// name
						sb.append("|");
						int k = 0;
						for (k = 0; k < (totals + 9 - name.length()) / 2; k++) {
							sb.append(' ');
						}
						sb.append(name);
						for (int i = 0; i < totals + 9 - name.length() - k; i++) {
							sb.append(' ');
						}
						sb.append("|\n");

						// head and rows
						sb.append(print(des_head));
						for (int i = 0; i < list.size(); i++) {

							String[] row = list.get(i);

							java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());

							StringBuilder sbformat = new StringBuilder();
							sbformat.append("|%1$-");
							sbformat.append(colLengths[0]);
							sbformat.append("s");

							sbformat.append("|%2$-");
							sbformat.append(colLengths[1]);
							sbformat.append("s");

							sbformat.append("|%3$-");
							sbformat.append(colLengths[2]);
							sbformat.append("s");

							sbformat.append("|%4$-");
							sbformat.append(colLengths[3]);
							sbformat.append("s");

							sbformat.append("|%5$-");
							sbformat.append(colLengths[4]);
							sbformat.append("s");

							sbformat.append("|%6$-");
							sbformat.append(colLengths[5]);
							sbformat.append("s");

							sbformat.append("|%7$-");
							sbformat.append(colLengths[6]);
							sbformat.append("s");

							sbformat.append("|%8$-");
							sbformat.append(colLengths[7]);
							sbformat.append("s");

							sbformat.append("|%9$-");
							sbformat.append(colLengths[8]);
							sbformat.append("s");

							sbformat.append("|%10$-");
							sbformat.append(colLengths[9]);
							sbformat.append("s");

							sbformat.append("|\n");

							formatter.format(sbformat.toString(), (Object[]) row);

							sb.append(formatter.toString());
							if (i == 0)
								sb.append(print(des_head)); // print the head
						}

						// end
						sb.append(print(des_bottom));
						return sb;
					}

					private StringBuilder print(String[] fillChars) {
						StringBuilder sb = new StringBuilder();
						// first column
						sb.append(fillChars[0]);
						for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);
						for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[3]);

						// last column
						for (int i = 0; i < colLengths[9] - fillChars[1].length() + 1; i++) {
							sb.append(fillChars[2]);
						}
						sb.append(fillChars[1]);
						sb.append("\n");
						return sb;
					}

					public boolean isTableEmpty() {
						if (list.size() > 1)
							return false;
						return true;
					}
				}
				Util_tLogRow_1 util_tLogRow_1 = new Util_tLogRow_1();
				util_tLogRow_1.setTableName("data_client_clean");
				util_tLogRow_1.addRow(new String[] { "numero_commande", "reference_produit", "CONDITIONNEMENT",
						"PRIX_UNITAIRE", "code_client", "quantite", "date_commande", "is_commande_annulee",
						"nom_magasin", "pays_magasin", });
				StringBuilder strBuffer_tLogRow_1 = null;
				int nb_line_tLogRow_1 = 0;
///////////////////////    			

				/**
				 * [tLogRow_1 begin ] stop
				 */

				/**
				 * [tLogRow_2 begin ] start
				 */

				ok_Hash.put("tLogRow_2", false);
				start_Hash.put("tLogRow_2", System.currentTimeMillis());

				currentComponent = "tLogRow_2";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "row1");

				int tos_count_tLogRow_2 = 0;

				if (log.isDebugEnabled())
					log.debug("tLogRow_2 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tLogRow_2 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tLogRow_2 = new StringBuilder();
							log4jParamters_tLogRow_2.append("Parameters:");
							log4jParamters_tLogRow_2.append("BASIC_MODE" + " = " + "true");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("TABLE_PRINT" + " = " + "false");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("VERTICAL" + " = " + "false");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("FIELDSEPARATOR" + " = " + "\"|\"");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("PRINT_HEADER" + " = " + "false");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("PRINT_UNIQUE_NAME" + " = " + "false");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("PRINT_COLNAMES" + " = " + "false");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("USE_FIXED_LENGTH" + " = " + "false");
							log4jParamters_tLogRow_2.append(" | ");
							log4jParamters_tLogRow_2.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
							log4jParamters_tLogRow_2.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tLogRow_2 - " + (log4jParamters_tLogRow_2));
						}
					}
					new BytesLimit65535_tLogRow_2().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tLogRow_2", "tLogRow_2", "tLogRow");
					talendJobLogProcess(globalMap);
				}

				///////////////////////

				final String OUTPUT_FIELD_SEPARATOR_tLogRow_2 = "|";
				java.io.PrintStream consoleOut_tLogRow_2 = null;

				StringBuilder strBuffer_tLogRow_2 = null;
				int nb_line_tLogRow_2 = 0;
///////////////////////    			

				/**
				 * [tLogRow_2 begin ] stop
				 */

				/**
				 * [tFilterRow_5 begin ] start
				 */

				ok_Hash.put("tFilterRow_5", false);
				start_Hash.put("tFilterRow_5", System.currentTimeMillis());

				currentComponent = "tFilterRow_5";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Cleaned");

				int tos_count_tFilterRow_5 = 0;

				if (log.isDebugEnabled())
					log.debug("tFilterRow_5 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFilterRow_5 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFilterRow_5 = new StringBuilder();
							log4jParamters_tFilterRow_5.append("Parameters:");
							log4jParamters_tFilterRow_5.append("LOGICAL_OP" + " = " + "&&");
							log4jParamters_tFilterRow_5.append(" | ");
							log4jParamters_tFilterRow_5.append("CONDITIONS" + " = " + "[{OPERATOR=" + ("!=")
									+ ", RVALUE=" + ("1") + ", INPUT_COLUMN=" + ("is_commande_annulee") + ", FUNCTION="
									+ ("Math.abs($source) $operator $target") + "}]");
							log4jParamters_tFilterRow_5.append(" | ");
							log4jParamters_tFilterRow_5.append("USE_ADVANCED" + " = " + "false");
							log4jParamters_tFilterRow_5.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFilterRow_5 - " + (log4jParamters_tFilterRow_5));
						}
					}
					new BytesLimit65535_tFilterRow_5().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFilterRow_5", "tFilterRow_5", "tFilterRow");
					talendJobLogProcess(globalMap);
				}

				int nb_line_tFilterRow_5 = 0;
				int nb_line_ok_tFilterRow_5 = 0;
				int nb_line_reject_tFilterRow_5 = 0;

				class Operator_tFilterRow_5 {
					private String sErrorMsg = "";
					private boolean bMatchFlag = true;
					private String sUnionFlag = "&&";

					public Operator_tFilterRow_5(String unionFlag) {
						sUnionFlag = unionFlag;
						bMatchFlag = "||".equals(unionFlag) ? false : true;
					}

					public String getErrorMsg() {
						if (sErrorMsg != null && sErrorMsg.length() > 1)
							return sErrorMsg.substring(1);
						else
							return null;
					}

					public boolean getMatchFlag() {
						return bMatchFlag;
					}

					public void matches(boolean partMatched, String reason) {
						// no need to care about the next judgement
						if ("||".equals(sUnionFlag) && bMatchFlag) {
							return;
						}

						if (!partMatched) {
							sErrorMsg += "|" + reason;
						}

						if ("||".equals(sUnionFlag))
							bMatchFlag = bMatchFlag || partMatched;
						else
							bMatchFlag = bMatchFlag && partMatched;
					}
				}

				/**
				 * [tFilterRow_5 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "cde");

				int tos_count_tMap_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tMap_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tMap_1 = new StringBuilder();
							log4jParamters_tMap_1.append("Parameters:");
							log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
							log4jParamters_tMap_1.append(" | ");
							log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "true");
							log4jParamters_tMap_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tMap_1 - " + (log4jParamters_tMap_1));
						}
					}
					new BytesLimit65535_tMap_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tMap_1", "tMap_1", "tMap");
					talendJobLogProcess(globalMap);
				}

// ###############################
// # Lookup's keys initialization
				int count_cde_tMap_1 = 0;

				int count_Cdes_tMap_1 = 0;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<CdesStruct> tHash_Lookup_Cdes = null;

				CdesStruct CdesHashKey = new CdesStruct();
				CdesStruct CdesDefault = new CdesStruct();
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_Cleaned_tMap_1 = 0;

				CleanedStruct Cleaned_tmp = new CleanedStruct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_1", false);
				start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_1";

				cLabel = "Charg_PU";

				int tos_count_tFileInputDelimited_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tFileInputDelimited_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tFileInputDelimited_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tFileInputDelimited_1 = new StringBuilder();
							log4jParamters_tFileInputDelimited_1.append("Parameters:");
							log4jParamters_tFileInputDelimited_1.append("USE_EXISTING_DYNAMIC" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("FILENAME" + " = "
									+ "\"C:/Users/MarieLEFEBVRE/Downloads/atlas_superstore_cond_pu.csv\"");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("CSV_OPTION" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("ROWSEPARATOR" + " = " + "\"\\n\"");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("FIELDSEPARATOR" + " = " + "\";\"");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("HEADER" + " = " + "1");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("FOOTER" + " = " + "0");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("LIMIT" + " = " + "");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("REMOVE_EMPTY_ROW" + " = " + "true");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("UNCOMPRESS" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("DIE_ON_ERROR" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("ADVANCED_SEPARATOR" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("RANDOM" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("TRIMALL" + " = " + "true");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("CHECK_FIELDS_NUM" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("CHECK_DATE" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("SPLITRECORD" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("ENABLE_DECODE" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							log4jParamters_tFileInputDelimited_1.append("USE_HEADER_AS_IS" + " = " + "false");
							log4jParamters_tFileInputDelimited_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tFileInputDelimited_1 - " + (log4jParamters_tFileInputDelimited_1));
						}
					}
					new BytesLimit65535_tFileInputDelimited_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tFileInputDelimited_1", "Charg_PU", "tFileInputDelimited");
					talendJobLogProcess(globalMap);
				}

				final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try {

					Object filename_tFileInputDelimited_1 = "C:/Users/MarieLEFEBVRE/Downloads/atlas_superstore_cond_pu.csv";
					if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
						if (footer_value_tFileInputDelimited_1 > 0 || random_value_tFileInputDelimited_1 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/MarieLEFEBVRE/Downloads/atlas_superstore_cond_pu.csv", "ISO-8859-15", ";",
								"\n", true, 1, 0, limit_tFileInputDelimited_1, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());

						log.error("tFileInputDelimited_1 - " + e.getMessage());

						System.err.println(e.getMessage());

					}

					log.info("tFileInputDelimited_1 - Retrieving records from the datasource.");

					while (fid_tFileInputDelimited_1 != null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();

						cde = null;

						boolean whetherReject_tFileInputDelimited_1 = false;
						cde = new cdeStruct();
						try {

							int columnIndexWithD_tFileInputDelimited_1 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_1 = 0;

							cde.REFERENCE = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1)
									.trim();

							columnIndexWithD_tFileInputDelimited_1 = 1;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1).trim();
							if (temp.length() > 0) {

								try {

									cde.CONDITIONNEMENT = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"CONDITIONNEMENT", "cde", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								cde.CONDITIONNEMENT = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 2;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1).trim();
							if (temp.length() > 0) {

								try {

									cde.PRIX_UNITAIRE = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"PRIX_UNITAIRE", "cde", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								cde.PRIX_UNITAIRE = null;

							}

							if (rowstate_tFileInputDelimited_1.getException() != null) {
								throw rowstate_tFileInputDelimited_1.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_1 = true;

							log.error("tFileInputDelimited_1 - " + e.getMessage());

							System.err.println(e.getMessage());
							cde = null;

						}

						log.debug("tFileInputDelimited_1 - Retrieving the record "
								+ fid_tFileInputDelimited_1.getRowNumber() + ".");

						/**
						 * [tFileInputDelimited_1 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_1 main ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						cLabel = "Charg_PU";

						tos_count_tFileInputDelimited_1++;

						/**
						 * [tFileInputDelimited_1 main ] stop
						 */

						/**
						 * [tFileInputDelimited_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						cLabel = "Charg_PU";

						/**
						 * [tFileInputDelimited_1 process_data_begin ] stop
						 */
// Start of branch "cde"
						if (cde != null) {
							row1 = null;

							/**
							 * [tMap_1 main ] start
							 */

							currentComponent = "tMap_1";

							if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

									, "cde", "tFileInputDelimited_1", "Charg_PU", "tFileInputDelimited", "tMap_1",
									"tMap_1", "tMap"

							)) {
								talendJobLogProcess(globalMap);
							}

							if (log.isTraceEnabled()) {
								log.trace("cde - " + (cde == null ? "" : cde.toLogString()));
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

							CdesStruct Cdes = null;

							// ###############################
							// # Input tables (lookups)

							boolean rejectedInnerJoin_tMap_1 = false;
							boolean mainRowRejected_tMap_1 = false;

							///////////////////////////////////////////////
							// Starting Lookup Table "Cdes"
							///////////////////////////////////////////////

							boolean forceLoopCdes = false;

							CdesStruct CdesObjectFromLookup = null;

							if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								hasCasePrimitiveKeyWithNull_tMap_1 = false;

								CdesHashKey.reference_produit = cde.REFERENCE.substring(0, cde.REFERENCE.length() - 5);

								CdesHashKey.hashCodeDirty = true;

								tDBInput_1Process(globalMap);

								tHash_Lookup_Cdes = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<CdesStruct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<CdesStruct>) globalMap
										.get("tHash_Lookup_Cdes"));

								tHash_Lookup_Cdes.initGet();

								tHash_Lookup_Cdes.lookup(CdesHashKey);

								if (!tHash_Lookup_Cdes.hasNext()) { // G_TM_M_090

									forceLoopCdes = true;

								} // G_TM_M_090

							} // G_TM_M_020

							else { // G 20 - G 21
								forceLoopCdes = true;
							} // G 21

							while ((tHash_Lookup_Cdes != null && tHash_Lookup_Cdes.hasNext()) || forceLoopCdes) { // G_TM_M_043

								// CALL close loop of lookup 'Cdes'

								CdesStruct fromLookup_Cdes = null;
								Cdes = CdesDefault;

								if (!forceLoopCdes) { // G 46

									fromLookup_Cdes = tHash_Lookup_Cdes.next();

									if (fromLookup_Cdes != null) {
										Cdes = fromLookup_Cdes;
									}

								} // G 46

								forceLoopCdes = false;

								// ###############################
								{ // start of Var scope

									// ###############################
									// # Vars tables

									Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
									// ###############################
									// # Output tables

									Cleaned = null;

// # Output table : 'Cleaned'
									count_Cleaned_tMap_1++;

									Cleaned_tmp.numero_commande = Cdes.numero_commande;
									Cleaned_tmp.reference_produit = Cdes.reference_produit;
									Cleaned_tmp.CONDITIONNEMENT = cde.CONDITIONNEMENT;
									Cleaned_tmp.PRIX_UNITAIRE = cde.PRIX_UNITAIRE;
									Cleaned_tmp.code_client = Cdes.code_client;
									Cleaned_tmp.quantite = Cdes.quantite;
									Cleaned_tmp.date_commande = Cdes.date_commande;
									Cleaned_tmp.is_commande_annulee = Cdes.is_commande_annulee;
									Cleaned_tmp.nom_magasin = Cdes.nom_magasin;
									Cleaned_tmp.pays_magasin = Cdes.pays_magasin;
									Cleaned = Cleaned_tmp;
									log.debug("tMap_1 - Outputting the record " + count_Cleaned_tMap_1
											+ " of the output table 'Cleaned'.");

// ###############################

								} // end of Var scope

								rejectedInnerJoin_tMap_1 = false;

								tos_count_tMap_1++;

								/**
								 * [tMap_1 main ] stop
								 */

								/**
								 * [tMap_1 process_data_begin ] start
								 */

								currentComponent = "tMap_1";

								/**
								 * [tMap_1 process_data_begin ] stop
								 */
// Start of branch "Cleaned"
								if (Cleaned != null) {
									row1 = null;

									/**
									 * [tFilterRow_5 main ] start
									 */

									currentComponent = "tFilterRow_5";

									if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

											, "Cleaned", "tMap_1", "tMap_1", "tMap", "tFilterRow_5", "tFilterRow_5",
											"tFilterRow"

									)) {
										talendJobLogProcess(globalMap);
									}

									if (log.isTraceEnabled()) {
										log.trace("Cleaned - " + (Cleaned == null ? "" : Cleaned.toLogString()));
									}

									row1 = null;
									cde_filtrees = null;
									Operator_tFilterRow_5 ope_tFilterRow_5 = new Operator_tFilterRow_5("&&");
									ope_tFilterRow_5.matches((Math.abs(Cleaned.is_commande_annulee) != 1),
											"Math.abs(is_commande_annulee) != 1 failed");

									if (ope_tFilterRow_5.getMatchFlag()) {
										if (cde_filtrees == null) {
											cde_filtrees = new cde_filtreesStruct();
										}
										cde_filtrees.numero_commande = Cleaned.numero_commande;
										cde_filtrees.reference_produit = Cleaned.reference_produit;
										cde_filtrees.CONDITIONNEMENT = Cleaned.CONDITIONNEMENT;
										cde_filtrees.PRIX_UNITAIRE = Cleaned.PRIX_UNITAIRE;
										cde_filtrees.code_client = Cleaned.code_client;
										cde_filtrees.quantite = Cleaned.quantite;
										cde_filtrees.date_commande = Cleaned.date_commande;
										cde_filtrees.is_commande_annulee = Cleaned.is_commande_annulee;
										cde_filtrees.nom_magasin = Cleaned.nom_magasin;
										cde_filtrees.pays_magasin = Cleaned.pays_magasin;
										log.debug("tFilterRow_5 - Process the record " + (nb_line_tFilterRow_5 + 1)
												+ ".");

										nb_line_ok_tFilterRow_5++;
									} else {
										if (row1 == null) {
											row1 = new row1Struct();
										}
										row1.numero_commande = Cleaned.numero_commande;
										row1.reference_produit = Cleaned.reference_produit;
										row1.CONDITIONNEMENT = Cleaned.CONDITIONNEMENT;
										row1.PRIX_UNITAIRE = Cleaned.PRIX_UNITAIRE;
										row1.code_client = Cleaned.code_client;
										row1.quantite = Cleaned.quantite;
										row1.date_commande = Cleaned.date_commande;
										row1.is_commande_annulee = Cleaned.is_commande_annulee;
										row1.nom_magasin = Cleaned.nom_magasin;
										row1.pays_magasin = Cleaned.pays_magasin;
										row1.errorMessage = ope_tFilterRow_5.getErrorMsg();
										log.debug("tFilterRow_5 - Process the record " + (nb_line_tFilterRow_5 + 1)
												+ ".");

										log.debug("tFilterRow_5 - Reject the record " + (nb_line_tFilterRow_5 + 1)
												+ ". Caused by: " + row1.errorMessage + ".");

										nb_line_reject_tFilterRow_5++;
									}

									nb_line_tFilterRow_5++;

									tos_count_tFilterRow_5++;

									/**
									 * [tFilterRow_5 main ] stop
									 */

									/**
									 * [tFilterRow_5 process_data_begin ] start
									 */

									currentComponent = "tFilterRow_5";

									/**
									 * [tFilterRow_5 process_data_begin ] stop
									 */
// Start of branch "cde_filtrees"
									if (cde_filtrees != null) {

										/**
										 * [tLogRow_1 main ] start
										 */

										currentComponent = "tLogRow_1";

										cLabel = "data_client_clean";

										if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

												, "cde_filtrees", "tFilterRow_5", "tFilterRow_5", "tFilterRow",
												"tLogRow_1", "data_client_clean", "tLogRow"

										)) {
											talendJobLogProcess(globalMap);
										}

										if (log.isTraceEnabled()) {
											log.trace("cde_filtrees - "
													+ (cde_filtrees == null ? "" : cde_filtrees.toLogString()));
										}

///////////////////////		

										String[] row_tLogRow_1 = new String[10];

										row_tLogRow_1[0] = String.valueOf(cde_filtrees.numero_commande);

										if (cde_filtrees.reference_produit != null) { //
											row_tLogRow_1[1] = String.valueOf(cde_filtrees.reference_produit);

										} //

										if (cde_filtrees.CONDITIONNEMENT != null) { //
											row_tLogRow_1[2] = String.valueOf(cde_filtrees.CONDITIONNEMENT);

										} //

										if (cde_filtrees.PRIX_UNITAIRE != null) { //
											row_tLogRow_1[3] = FormatterUtils.formatUnwithE(cde_filtrees.PRIX_UNITAIRE);

										} //

										row_tLogRow_1[4] = String.valueOf(cde_filtrees.code_client);

										row_tLogRow_1[5] = String.valueOf(cde_filtrees.quantite);

										if (cde_filtrees.date_commande != null) { //
											row_tLogRow_1[6] = FormatterUtils.format_Date(cde_filtrees.date_commande,
													"dd/MM/yyyy HH:mm:ss");

										} //

										row_tLogRow_1[7] = String.valueOf(cde_filtrees.is_commande_annulee);

										if (cde_filtrees.nom_magasin != null) { //
											row_tLogRow_1[8] = String.valueOf(cde_filtrees.nom_magasin);

										} //

										if (cde_filtrees.pays_magasin != null) { //
											row_tLogRow_1[9] = String.valueOf(cde_filtrees.pays_magasin);

										} //

										util_tLogRow_1.addRow(row_tLogRow_1);
										nb_line_tLogRow_1++;
										log.info("tLogRow_1 - Content of row " + nb_line_tLogRow_1 + ": "
												+ TalendString.unionString("|", row_tLogRow_1));
//////

//////                    

///////////////////////    			

										cde_cleaned = cde_filtrees;

										tos_count_tLogRow_1++;

										/**
										 * [tLogRow_1 main ] stop
										 */

										/**
										 * [tLogRow_1 process_data_begin ] start
										 */

										currentComponent = "tLogRow_1";

										cLabel = "data_client_clean";

										/**
										 * [tLogRow_1 process_data_begin ] stop
										 */

										/**
										 * [tDBOutput_1 main ] start
										 */

										currentComponent = "tDBOutput_1";

										cLabel = "sortie_stg";

										if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

												, "cde_cleaned", "tLogRow_1", "data_client_clean", "tLogRow",
												"tDBOutput_1", "sortie_stg", "tMysqlOutput"

										)) {
											talendJobLogProcess(globalMap);
										}

										if (log.isTraceEnabled()) {
											log.trace("cde_cleaned - "
													+ (cde_cleaned == null ? "" : cde_cleaned.toLogString()));
										}

										whetherReject_tDBOutput_1 = false;
										int updateFlag_tDBOutput_1 = 0;
										if (cde_cleaned.reference_produit == null) {
											pstmtUpdate_tDBOutput_1.setNull(1, java.sql.Types.VARCHAR);
										} else {
											pstmtUpdate_tDBOutput_1.setString(1, cde_cleaned.reference_produit);
										}

										if (cde_cleaned.CONDITIONNEMENT == null) {
											pstmtUpdate_tDBOutput_1.setNull(2, java.sql.Types.INTEGER);
										} else {
											pstmtUpdate_tDBOutput_1.setInt(2, cde_cleaned.CONDITIONNEMENT);
										}

										if (cde_cleaned.PRIX_UNITAIRE == null) {
											pstmtUpdate_tDBOutput_1.setNull(3, java.sql.Types.FLOAT);
										} else {
											pstmtUpdate_tDBOutput_1.setFloat(3, cde_cleaned.PRIX_UNITAIRE);
										}

										pstmtUpdate_tDBOutput_1.setInt(4, cde_cleaned.code_client);

										pstmtUpdate_tDBOutput_1.setInt(5, cde_cleaned.quantite);

										if (cde_cleaned.date_commande != null) {
											date_tDBOutput_1 = cde_cleaned.date_commande.getTime();
											if (date_tDBOutput_1 < year1_tDBOutput_1
													|| date_tDBOutput_1 >= year10000_tDBOutput_1) {
												pstmtUpdate_tDBOutput_1.setString(6, "0000-00-00 00:00:00");
											} else {
												pstmtUpdate_tDBOutput_1.setTimestamp(6,
														new java.sql.Timestamp(date_tDBOutput_1));
											}
										} else {
											pstmtUpdate_tDBOutput_1.setNull(6, java.sql.Types.DATE);
										}

										pstmtUpdate_tDBOutput_1.setInt(7, cde_cleaned.is_commande_annulee);

										if (cde_cleaned.nom_magasin == null) {
											pstmtUpdate_tDBOutput_1.setNull(8, java.sql.Types.VARCHAR);
										} else {
											pstmtUpdate_tDBOutput_1.setString(8, cde_cleaned.nom_magasin);
										}

										if (cde_cleaned.pays_magasin == null) {
											pstmtUpdate_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
										} else {
											pstmtUpdate_tDBOutput_1.setString(9, cde_cleaned.pays_magasin);
										}

										pstmtUpdate_tDBOutput_1.setInt(10 + count_tDBOutput_1,
												cde_cleaned.numero_commande);

										try {
											updateFlag_tDBOutput_1 = pstmtUpdate_tDBOutput_1.executeUpdate();
											updatedCount_tDBOutput_1 = updatedCount_tDBOutput_1
													+ updateFlag_tDBOutput_1;
											rowsToCommitCount_tDBOutput_1 += updateFlag_tDBOutput_1;

											if (updateFlag_tDBOutput_1 == 0) {

												pstmtInsert_tDBOutput_1.setInt(1, cde_cleaned.numero_commande);

												if (cde_cleaned.reference_produit == null) {
													pstmtInsert_tDBOutput_1.setNull(2, java.sql.Types.VARCHAR);
												} else {
													pstmtInsert_tDBOutput_1.setString(2, cde_cleaned.reference_produit);
												}

												if (cde_cleaned.CONDITIONNEMENT == null) {
													pstmtInsert_tDBOutput_1.setNull(3, java.sql.Types.INTEGER);
												} else {
													pstmtInsert_tDBOutput_1.setInt(3, cde_cleaned.CONDITIONNEMENT);
												}

												if (cde_cleaned.PRIX_UNITAIRE == null) {
													pstmtInsert_tDBOutput_1.setNull(4, java.sql.Types.FLOAT);
												} else {
													pstmtInsert_tDBOutput_1.setFloat(4, cde_cleaned.PRIX_UNITAIRE);
												}

												pstmtInsert_tDBOutput_1.setInt(5, cde_cleaned.code_client);

												pstmtInsert_tDBOutput_1.setInt(6, cde_cleaned.quantite);

												if (cde_cleaned.date_commande != null) {
													date_tDBOutput_1 = cde_cleaned.date_commande.getTime();
													if (date_tDBOutput_1 < year1_tDBOutput_1
															|| date_tDBOutput_1 >= year10000_tDBOutput_1) {
														pstmtInsert_tDBOutput_1.setString(7, "0000-00-00 00:00:00");
													} else {
														pstmtInsert_tDBOutput_1.setTimestamp(7,
																new java.sql.Timestamp(date_tDBOutput_1));
													}
												} else {
													pstmtInsert_tDBOutput_1.setNull(7, java.sql.Types.DATE);
												}

												pstmtInsert_tDBOutput_1.setInt(8, cde_cleaned.is_commande_annulee);

												if (cde_cleaned.nom_magasin == null) {
													pstmtInsert_tDBOutput_1.setNull(9, java.sql.Types.VARCHAR);
												} else {
													pstmtInsert_tDBOutput_1.setString(9, cde_cleaned.nom_magasin);
												}

												if (cde_cleaned.pays_magasin == null) {
													pstmtInsert_tDBOutput_1.setNull(10, java.sql.Types.VARCHAR);
												} else {
													pstmtInsert_tDBOutput_1.setString(10, cde_cleaned.pays_magasin);
												}

												int processedCount_tDBOutput_1 = pstmtInsert_tDBOutput_1
														.executeUpdate();
												insertedCount_tDBOutput_1 += processedCount_tDBOutput_1;
												rowsToCommitCount_tDBOutput_1 += processedCount_tDBOutput_1;
												nb_line_tDBOutput_1++;
												if (log.isDebugEnabled())
													log.debug("tDBOutput_1 - " + ("Inserting") + (" the record ")
															+ (nb_line_tDBOutput_1) + ("."));
											} else {
												nb_line_tDBOutput_1++;
												if (log.isDebugEnabled())
													log.debug("tDBOutput_1 - " + ("Updating") + (" the record ")
															+ (nb_line_tDBOutput_1) + ("."));
											}
										} catch (java.lang.Exception e) {
											globalMap.put("tDBOutput_1_ERROR_MESSAGE", e.getMessage());
											whetherReject_tDBOutput_1 = true;
											throw (e);
										}

										tos_count_tDBOutput_1++;

										/**
										 * [tDBOutput_1 main ] stop
										 */

										/**
										 * [tDBOutput_1 process_data_begin ] start
										 */

										currentComponent = "tDBOutput_1";

										cLabel = "sortie_stg";

										/**
										 * [tDBOutput_1 process_data_begin ] stop
										 */

										/**
										 * [tDBOutput_1 process_data_end ] start
										 */

										currentComponent = "tDBOutput_1";

										cLabel = "sortie_stg";

										/**
										 * [tDBOutput_1 process_data_end ] stop
										 */

										/**
										 * [tLogRow_1 process_data_end ] start
										 */

										currentComponent = "tLogRow_1";

										cLabel = "data_client_clean";

										/**
										 * [tLogRow_1 process_data_end ] stop
										 */

									} // End of branch "cde_filtrees"

// Start of branch "row1"
									if (row1 != null) {

										/**
										 * [tLogRow_2 main ] start
										 */

										currentComponent = "tLogRow_2";

										if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

												, "row1", "tFilterRow_5", "tFilterRow_5", "tFilterRow", "tLogRow_2",
												"tLogRow_2", "tLogRow"

										)) {
											talendJobLogProcess(globalMap);
										}

										if (log.isTraceEnabled()) {
											log.trace("row1 - " + (row1 == null ? "" : row1.toLogString()));
										}

///////////////////////		

										strBuffer_tLogRow_2 = new StringBuilder();

										strBuffer_tLogRow_2.append(String.valueOf(row1.numero_commande));

										strBuffer_tLogRow_2.append("|");

										if (row1.reference_produit != null) { //

											strBuffer_tLogRow_2.append(String.valueOf(row1.reference_produit));

										} //

										strBuffer_tLogRow_2.append("|");

										if (row1.CONDITIONNEMENT != null) { //

											strBuffer_tLogRow_2.append(String.valueOf(row1.CONDITIONNEMENT));

										} //

										strBuffer_tLogRow_2.append("|");

										if (row1.PRIX_UNITAIRE != null) { //

											strBuffer_tLogRow_2
													.append(FormatterUtils.formatUnwithE(row1.PRIX_UNITAIRE));

										} //

										strBuffer_tLogRow_2.append("|");

										strBuffer_tLogRow_2.append(String.valueOf(row1.code_client));

										strBuffer_tLogRow_2.append("|");

										strBuffer_tLogRow_2.append(String.valueOf(row1.quantite));

										strBuffer_tLogRow_2.append("|");

										if (row1.date_commande != null) { //

											strBuffer_tLogRow_2.append(FormatterUtils.format_Date(row1.date_commande,
													"dd/MM/yyyy HH:mm:ss"));

										} //

										strBuffer_tLogRow_2.append("|");

										strBuffer_tLogRow_2.append(String.valueOf(row1.is_commande_annulee));

										strBuffer_tLogRow_2.append("|");

										if (row1.nom_magasin != null) { //

											strBuffer_tLogRow_2.append(String.valueOf(row1.nom_magasin));

										} //

										strBuffer_tLogRow_2.append("|");

										if (row1.pays_magasin != null) { //

											strBuffer_tLogRow_2.append(String.valueOf(row1.pays_magasin));

										} //

										strBuffer_tLogRow_2.append("|");

										if (row1.errorMessage != null) { //

											strBuffer_tLogRow_2.append(String.valueOf(row1.errorMessage));

										} //

										if (globalMap.get("tLogRow_CONSOLE") != null) {
											consoleOut_tLogRow_2 = (java.io.PrintStream) globalMap
													.get("tLogRow_CONSOLE");
										} else {
											consoleOut_tLogRow_2 = new java.io.PrintStream(
													new java.io.BufferedOutputStream(System.out));
											globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_2);
										}
										log.info("tLogRow_2 - Content of row " + (nb_line_tLogRow_2 + 1) + ": "
												+ strBuffer_tLogRow_2.toString());
										consoleOut_tLogRow_2.println(strBuffer_tLogRow_2.toString());
										consoleOut_tLogRow_2.flush();
										nb_line_tLogRow_2++;
//////

//////                    

///////////////////////    			

										tos_count_tLogRow_2++;

										/**
										 * [tLogRow_2 main ] stop
										 */

										/**
										 * [tLogRow_2 process_data_begin ] start
										 */

										currentComponent = "tLogRow_2";

										/**
										 * [tLogRow_2 process_data_begin ] stop
										 */

										/**
										 * [tLogRow_2 process_data_end ] start
										 */

										currentComponent = "tLogRow_2";

										/**
										 * [tLogRow_2 process_data_end ] stop
										 */

									} // End of branch "row1"

									/**
									 * [tFilterRow_5 process_data_end ] start
									 */

									currentComponent = "tFilterRow_5";

									/**
									 * [tFilterRow_5 process_data_end ] stop
									 */

								} // End of branch "Cleaned"

							} // close loop of lookup 'Cdes' // G_TM_M_043

							/**
							 * [tMap_1 process_data_end ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_end ] stop
							 */

						} // End of branch "cde"

						/**
						 * [tFileInputDelimited_1 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						cLabel = "Charg_PU";

						/**
						 * [tFileInputDelimited_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_1 end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						cLabel = "Charg_PU";

					}
				} finally {
					if (!((Object) ("C:/Users/MarieLEFEBVRE/Downloads/atlas_superstore_cond_pu.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_1 != null) {
							fid_tFileInputDelimited_1.close();
						}
					}
					if (fid_tFileInputDelimited_1 != null) {
						globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());

						log.info("tFileInputDelimited_1 - Retrieved records count: "
								+ fid_tFileInputDelimited_1.getRowNumber() + ".");

					}
				}

				if (log.isDebugEnabled())
					log.debug("tFileInputDelimited_1 - " + ("Done."));

				ok_Hash.put("tFileInputDelimited_1", true);
				end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_1 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
				if (tHash_Lookup_Cdes != null) {
					tHash_Lookup_Cdes.endGet();
				}
				globalMap.remove("tHash_Lookup_Cdes");

// ###############################      
				log.debug("tMap_1 - Written records count in the table 'Cleaned': " + count_Cleaned_tMap_1 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "cde", 2, 0,
						"tFileInputDelimited_1", "Charg_PU", "tFileInputDelimited", "tMap_1", "tMap_1", "tMap",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tMap_1 - " + ("Done."));

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tFilterRow_5 end ] start
				 */

				currentComponent = "tFilterRow_5";

				globalMap.put("tFilterRow_5_NB_LINE", nb_line_tFilterRow_5);
				globalMap.put("tFilterRow_5_NB_LINE_OK", nb_line_ok_tFilterRow_5);
				globalMap.put("tFilterRow_5_NB_LINE_REJECT", nb_line_reject_tFilterRow_5);

				log.info("tFilterRow_5 - Processed records count:" + nb_line_tFilterRow_5 + ". Matched records count:"
						+ nb_line_ok_tFilterRow_5 + ". Rejected records count:" + nb_line_reject_tFilterRow_5 + ".");

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Cleaned", 2, 0,
						"tMap_1", "tMap_1", "tMap", "tFilterRow_5", "tFilterRow_5", "tFilterRow", "output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tFilterRow_5 - " + ("Done."));

				ok_Hash.put("tFilterRow_5", true);
				end_Hash.put("tFilterRow_5", System.currentTimeMillis());

				/**
				 * [tFilterRow_5 end ] stop
				 */

				/**
				 * [tLogRow_1 end ] start
				 */

				currentComponent = "tLogRow_1";

				cLabel = "data_client_clean";

//////

				java.io.PrintStream consoleOut_tLogRow_1 = null;
				if (globalMap.get("tLogRow_CONSOLE") != null) {
					consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
				} else {
					consoleOut_tLogRow_1 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
					globalMap.put("tLogRow_CONSOLE", consoleOut_tLogRow_1);
				}

				consoleOut_tLogRow_1.println(util_tLogRow_1.format().toString());
				consoleOut_tLogRow_1.flush();
//////
				globalMap.put("tLogRow_1_NB_LINE", nb_line_tLogRow_1);
				if (log.isInfoEnabled())
					log.info("tLogRow_1 - " + ("Printed row count: ") + (nb_line_tLogRow_1) + ("."));

///////////////////////    			

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "cde_filtrees", 2, 0,
						"tFilterRow_5", "tFilterRow_5", "tFilterRow", "tLogRow_1", "data_client_clean", "tLogRow",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tLogRow_1 - " + ("Done."));

				ok_Hash.put("tLogRow_1", true);
				end_Hash.put("tLogRow_1", System.currentTimeMillis());

				/**
				 * [tLogRow_1 end ] stop
				 */

				/**
				 * [tDBOutput_1 end ] start
				 */

				currentComponent = "tDBOutput_1";

				cLabel = "sortie_stg";

				if (pstmtUpdate_tDBOutput_1 != null) {
					pstmtUpdate_tDBOutput_1.close();
					resourceMap.remove("pstmtUpdate_tDBOutput_1");
				}
				if (pstmtInsert_tDBOutput_1 != null) {
					pstmtInsert_tDBOutput_1.close();
					resourceMap.remove("pstmtInsert_tDBOutput_1");
				}

				resourceMap.put("statementClosed_tDBOutput_1", true);

				nb_line_deleted_tDBOutput_1 = nb_line_deleted_tDBOutput_1 + deletedCount_tDBOutput_1;
				nb_line_update_tDBOutput_1 = nb_line_update_tDBOutput_1 + updatedCount_tDBOutput_1;
				nb_line_inserted_tDBOutput_1 = nb_line_inserted_tDBOutput_1 + insertedCount_tDBOutput_1;
				nb_line_rejected_tDBOutput_1 = nb_line_rejected_tDBOutput_1 + rejectedCount_tDBOutput_1;

				globalMap.put("tDBOutput_1_NB_LINE", nb_line_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_UPDATED", nb_line_update_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_INSERTED", nb_line_inserted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_DELETED", nb_line_deleted_tDBOutput_1);
				globalMap.put("tDBOutput_1_NB_LINE_REJECTED", nb_line_rejected_tDBOutput_1);

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Has ") + ("updated") + (" ") + (nb_line_update_tDBOutput_1)
							+ (" record(s)."));
				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Has ") + ("inserted") + (" ") + (nb_line_inserted_tDBOutput_1)
							+ (" record(s)."));

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "cde_cleaned", 2, 0,
						"tLogRow_1", "data_client_clean", "tLogRow", "tDBOutput_1", "sortie_stg", "tMysqlOutput",
						"output")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tDBOutput_1 - " + ("Done."));

				ok_Hash.put("tDBOutput_1", true);
				end_Hash.put("tDBOutput_1", System.currentTimeMillis());

				/**
				 * [tDBOutput_1 end ] stop
				 */

				/**
				 * [tLogRow_2 end ] start
				 */

				currentComponent = "tLogRow_2";

//////
//////
				globalMap.put("tLogRow_2_NB_LINE", nb_line_tLogRow_2);
				if (log.isInfoEnabled())
					log.info("tLogRow_2 - " + ("Printed row count: ") + (nb_line_tLogRow_2) + ("."));

///////////////////////    			

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "row1", 2, 0,
						"tFilterRow_5", "tFilterRow_5", "tFilterRow", "tLogRow_2", "tLogRow_2", "tLogRow", "reject")) {
					talendJobLogProcess(globalMap);
				}

				if (log.isDebugEnabled())
					log.debug("tLogRow_2 - " + ("Done."));

				ok_Hash.put("tLogRow_2", true);
				end_Hash.put("tLogRow_2", System.currentTimeMillis());

				/**
				 * [tLogRow_2 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_Cdes");

			try {

				/**
				 * [tFileInputDelimited_1 finally ] start
				 */

				currentComponent = "tFileInputDelimited_1";

				cLabel = "Charg_PU";

				/**
				 * [tFileInputDelimited_1 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tFilterRow_5 finally ] start
				 */

				currentComponent = "tFilterRow_5";

				/**
				 * [tFilterRow_5 finally ] stop
				 */

				/**
				 * [tLogRow_1 finally ] start
				 */

				currentComponent = "tLogRow_1";

				cLabel = "data_client_clean";

				/**
				 * [tLogRow_1 finally ] stop
				 */

				/**
				 * [tDBOutput_1 finally ] start
				 */

				currentComponent = "tDBOutput_1";

				cLabel = "sortie_stg";

				if (resourceMap.get("statementClosed_tDBOutput_1") == null) {
					java.sql.PreparedStatement pstmtUpdateToClose_tDBOutput_1 = null;
					if ((pstmtUpdateToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
							.remove("pstmtUpdate_tDBOutput_1")) != null) {
						pstmtUpdateToClose_tDBOutput_1.close();
					}
					java.sql.PreparedStatement pstmtInsertToClose_tDBOutput_1 = null;
					if ((pstmtInsertToClose_tDBOutput_1 = (java.sql.PreparedStatement) resourceMap
							.remove("pstmtInsert_tDBOutput_1")) != null) {
						pstmtInsertToClose_tDBOutput_1.close();
					}
				}

				/**
				 * [tDBOutput_1 finally ] stop
				 */

				/**
				 * [tLogRow_2 finally ] start
				 */

				currentComponent = "tLogRow_2";

				/**
				 * [tLogRow_2 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public static class CdesStruct implements routines.system.IPersistableComparableLookupRow<CdesStruct> {
		final static byte[] commonByteArrayLock_TMC_GIT_Atlas_superstore_cde = new byte[0];
		static byte[] commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int numero_commande;

		public int getNumero_commande() {
			return this.numero_commande;
		}

		public Boolean numero_commandeIsNullable() {
			return false;
		}

		public Boolean numero_commandeIsKey() {
			return true;
		}

		public Integer numero_commandeLength() {
			return 11;
		}

		public Integer numero_commandePrecision() {
			return 0;
		}

		public String numero_commandeDefault() {

			return "";

		}

		public String numero_commandeComment() {

			return "";

		}

		public String numero_commandePattern() {

			return "";

		}

		public String numero_commandeOriginalDbColumnName() {

			return "numero_commande";

		}

		public int code_client;

		public int getCode_client() {
			return this.code_client;
		}

		public Boolean code_clientIsNullable() {
			return false;
		}

		public Boolean code_clientIsKey() {
			return false;
		}

		public Integer code_clientLength() {
			return 11;
		}

		public Integer code_clientPrecision() {
			return 0;
		}

		public String code_clientDefault() {

			return "";

		}

		public String code_clientComment() {

			return "";

		}

		public String code_clientPattern() {

			return "";

		}

		public String code_clientOriginalDbColumnName() {

			return "code_client";

		}

		public String reference_produit;

		public String getReference_produit() {
			return this.reference_produit;
		}

		public Boolean reference_produitIsNullable() {
			return false;
		}

		public Boolean reference_produitIsKey() {
			return false;
		}

		public Integer reference_produitLength() {
			return 50;
		}

		public Integer reference_produitPrecision() {
			return 0;
		}

		public String reference_produitDefault() {

			return null;

		}

		public String reference_produitComment() {

			return "";

		}

		public String reference_produitPattern() {

			return "";

		}

		public String reference_produitOriginalDbColumnName() {

			return "reference_produit";

		}

		public int quantite;

		public int getQuantite() {
			return this.quantite;
		}

		public Boolean quantiteIsNullable() {
			return false;
		}

		public Boolean quantiteIsKey() {
			return false;
		}

		public Integer quantiteLength() {
			return 11;
		}

		public Integer quantitePrecision() {
			return 0;
		}

		public String quantiteDefault() {

			return "";

		}

		public String quantiteComment() {

			return "";

		}

		public String quantitePattern() {

			return "";

		}

		public String quantiteOriginalDbColumnName() {

			return "quantite";

		}

		public java.util.Date date_commande;

		public java.util.Date getDate_commande() {
			return this.date_commande;
		}

		public Boolean date_commandeIsNullable() {
			return false;
		}

		public Boolean date_commandeIsKey() {
			return false;
		}

		public Integer date_commandeLength() {
			return 19;
		}

		public Integer date_commandePrecision() {
			return 0;
		}

		public String date_commandeDefault() {

			return null;

		}

		public String date_commandeComment() {

			return "";

		}

		public String date_commandePattern() {

			return "dd/MM/yyyy HH:mm:ss";

		}

		public String date_commandeOriginalDbColumnName() {

			return "date_commande";

		}

		public int is_commande_annulee;

		public int getIs_commande_annulee() {
			return this.is_commande_annulee;
		}

		public Boolean is_commande_annuleeIsNullable() {
			return false;
		}

		public Boolean is_commande_annuleeIsKey() {
			return false;
		}

		public Integer is_commande_annuleeLength() {
			return 1;
		}

		public Integer is_commande_annuleePrecision() {
			return 0;
		}

		public String is_commande_annuleeDefault() {

			return "";

		}

		public String is_commande_annuleeComment() {

			return "";

		}

		public String is_commande_annuleePattern() {

			return "";

		}

		public String is_commande_annuleeOriginalDbColumnName() {

			return "is_commande_annulee";

		}

		public String nom_magasin;

		public String getNom_magasin() {
			return this.nom_magasin;
		}

		public Boolean nom_magasinIsNullable() {
			return false;
		}

		public Boolean nom_magasinIsKey() {
			return false;
		}

		public Integer nom_magasinLength() {
			return 255;
		}

		public Integer nom_magasinPrecision() {
			return 0;
		}

		public String nom_magasinDefault() {

			return null;

		}

		public String nom_magasinComment() {

			return "";

		}

		public String nom_magasinPattern() {

			return "";

		}

		public String nom_magasinOriginalDbColumnName() {

			return "nom_magasin";

		}

		public String pays_magasin;

		public String getPays_magasin() {
			return this.pays_magasin;
		}

		public Boolean pays_magasinIsNullable() {
			return false;
		}

		public Boolean pays_magasinIsKey() {
			return false;
		}

		public Integer pays_magasinLength() {
			return 255;
		}

		public Integer pays_magasinPrecision() {
			return 0;
		}

		public String pays_magasinDefault() {

			return null;

		}

		public String pays_magasinComment() {

			return "";

		}

		public String pays_magasinPattern() {

			return "";

		}

		public String pays_magasinOriginalDbColumnName() {

			return "pays_magasin";

		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.reference_produit == null) ? 0 : this.reference_produit.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final CdesStruct other = (CdesStruct) obj;

			if (this.reference_produit == null) {
				if (other.reference_produit != null)
					return false;

			} else if (!this.reference_produit.equals(other.reference_produit))

				return false;

			return true;
		}

		public void copyDataTo(CdesStruct other) {

			other.numero_commande = this.numero_commande;
			other.code_client = this.code_client;
			other.reference_produit = this.reference_produit;
			other.quantite = this.quantite;
			other.date_commande = this.date_commande;
			other.is_commande_annulee = this.is_commande_annulee;
			other.nom_magasin = this.nom_magasin;
			other.pays_magasin = this.pays_magasin;

		}

		public void copyKeysDataTo(CdesStruct other) {

			other.reference_produit = this.reference_produit;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TMC_GIT_Atlas_superstore_cde.length) {
					if (length < 1024 && commonByteArray_TMC_GIT_Atlas_superstore_cde.length == 0) {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[1024];
					} else {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length);
				strReturn = new String(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_TMC_GIT_Atlas_superstore_cde.length) {
					if (length < 1024 && commonByteArray_TMC_GIT_Atlas_superstore_cde.length == 0) {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[1024];
					} else {
						commonByteArray_TMC_GIT_Atlas_superstore_cde = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length);
				strReturn = new String(commonByteArray_TMC_GIT_Atlas_superstore_cde, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private java.util.Date readDate(DataInputStream dis, ObjectInputStream ois) throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(dis.readLong());
			}
			return dateReturn;
		}

		private java.util.Date readDate(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			java.util.Date dateReturn = null;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				dateReturn = null;
			} else {
				dateReturn = new Date(unmarshaller.readLong());
			}
			return dateReturn;
		}

		private void writeDate(java.util.Date date1, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (date1 == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeLong(date1.getTime());
			}
		}

		private void writeDate(java.util.Date date1, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (date1 == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeLong(date1.getTime());
			}
		}

		private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				unmarshaller.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_TMC_GIT_Atlas_superstore_cde) {

				try {

					int length = 0;

					this.reference_produit = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_TMC_GIT_Atlas_superstore_cde) {

				try {

					int length = 0;

					this.reference_produit = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// String

				writeString(this.reference_produit, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// String

				writeString(this.reference_produit, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.numero_commande = dis.readInt();

				this.code_client = dis.readInt();

				this.quantite = dis.readInt();

				this.date_commande = readDate(dis, ois);

				this.is_commande_annulee = dis.readInt();

				this.nom_magasin = readString(dis, ois);

				this.pays_magasin = readString(dis, ois);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				this.numero_commande = objectIn.readInt();

				this.code_client = objectIn.readInt();

				this.quantite = objectIn.readInt();

				this.date_commande = readDate(dis, objectIn);

				this.is_commande_annulee = objectIn.readInt();

				this.nom_magasin = readString(dis, objectIn);

				this.pays_magasin = readString(dis, objectIn);

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				dos.writeInt(this.numero_commande);

				dos.writeInt(this.code_client);

				dos.writeInt(this.quantite);

				writeDate(this.date_commande, dos, oos);

				dos.writeInt(this.is_commande_annulee);

				writeString(this.nom_magasin, dos, oos);

				writeString(this.pays_magasin, dos, oos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				objectOut.writeInt(this.numero_commande);

				objectOut.writeInt(this.code_client);

				objectOut.writeInt(this.quantite);

				writeDate(this.date_commande, dos, objectOut);

				objectOut.writeInt(this.is_commande_annulee);

				writeString(this.nom_magasin, dos, objectOut);

				writeString(this.pays_magasin, dos, objectOut);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("numero_commande=" + String.valueOf(numero_commande));
			sb.append(",code_client=" + String.valueOf(code_client));
			sb.append(",reference_produit=" + reference_produit);
			sb.append(",quantite=" + String.valueOf(quantite));
			sb.append(",date_commande=" + String.valueOf(date_commande));
			sb.append(",is_commande_annulee=" + String.valueOf(is_commande_annulee));
			sb.append(",nom_magasin=" + nom_magasin);
			sb.append(",pays_magasin=" + pays_magasin);
			sb.append("]");

			return sb.toString();
		}

		public String toLogString() {
			StringBuilder sb = new StringBuilder();

			sb.append(numero_commande);

			sb.append("|");

			sb.append(code_client);

			sb.append("|");

			if (reference_produit == null) {
				sb.append("<null>");
			} else {
				sb.append(reference_produit);
			}

			sb.append("|");

			sb.append(quantite);

			sb.append("|");

			if (date_commande == null) {
				sb.append("<null>");
			} else {
				sb.append(date_commande);
			}

			sb.append("|");

			sb.append(is_commande_annulee);

			sb.append("|");

			if (nom_magasin == null) {
				sb.append("<null>");
			} else {
				sb.append(nom_magasin);
			}

			sb.append("|");

			if (pays_magasin == null) {
				sb.append("<null>");
			} else {
				sb.append(pays_magasin);
			}

			sb.append("|");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(CdesStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.reference_produit, other.reference_produit);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tDBInput_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBInput_1");
		org.slf4j.MDC.put("_subJobPid", "TV4wT8_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				CdesStruct Cdes = new CdesStruct();

				/**
				 * [tAdvancedHash_Cdes begin ] start
				 */

				ok_Hash.put("tAdvancedHash_Cdes", false);
				start_Hash.put("tAdvancedHash_Cdes", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_Cdes";

				runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, 0, 0, "Cdes");

				int tos_count_tAdvancedHash_Cdes = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tAdvancedHash_Cdes", "tAdvancedHash_Cdes", "tAdvancedHash");
					talendJobLogProcess(globalMap);
				}

				// connection name:Cdes
				// source node:tDBInput_1 - inputs:() outputs:(Cdes,Cdes) | target
				// node:tAdvancedHash_Cdes - inputs:(Cdes) outputs:()
				// linked node: tMap_1 - inputs:(cde,Cdes) outputs:(Cleaned)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_Cdes = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.ALL_MATCHES;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<CdesStruct> tHash_Lookup_Cdes = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<CdesStruct>getLookup(matchingModeEnum_Cdes);

				globalMap.put("tHash_Lookup_Cdes", tHash_Lookup_Cdes);

				/**
				 * [tAdvancedHash_Cdes begin ] stop
				 */

				/**
				 * [tDBInput_1 begin ] start
				 */

				ok_Hash.put("tDBInput_1", false);
				start_Hash.put("tDBInput_1", System.currentTimeMillis());

				currentComponent = "tDBInput_1";

				cLabel = "Cde_mariadb";

				int tos_count_tDBInput_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBInput_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBInput_1 = new StringBuilder();
							log4jParamters_tDBInput_1.append("Parameters:");
							log4jParamters_tDBInput_1.append("USE_EXISTING_CONNECTION" + " = " + "true");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("CONNECTION" + " = " + "tDBConnection_1");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TABLE" + " = " + "\"atlas_superstore_commandes\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERYSTORE" + " = " + "\"\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("QUERY" + " = "
									+ "\"SELECT    `atlas_superstore_commandes`.`NUMERO_COMMANDE`,    `atlas_superstore_commandes`.`CODE_CLIENT`,    `atlas_superstore_commandes`.`REFERENCE_PRODUIT`,    `atlas_superstore_commandes`.`QUANTITE`,    `atlas_superstore_commandes`.`DATE_COMMANDE`,    `atlas_superstore_commandes`.`IS_COMMANDE_ANNULEE`,    `atlas_superstore_commandes`.`NOM_MAGASIN`,    `atlas_superstore_commandes`.`PAYS_MAGASIN` FROM `atlas_superstore_commandes`\"");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("TRIM_ALL_COLUMN" + " = " + "true");
							log4jParamters_tDBInput_1.append(" | ");
							log4jParamters_tDBInput_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlInput");
							log4jParamters_tDBInput_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBInput_1 - " + (log4jParamters_tDBInput_1));
						}
					}
					new BytesLimit65535_tDBInput_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBInput_1", "Cde_mariadb", "tMysqlInput");
					talendJobLogProcess(globalMap);
				}

				java.util.Calendar calendar_tDBInput_1 = java.util.Calendar.getInstance();
				calendar_tDBInput_1.set(0, 0, 0, 0, 0, 0);
				java.util.Date year0_tDBInput_1 = calendar_tDBInput_1.getTime();
				int nb_line_tDBInput_1 = 0;
				java.sql.Connection conn_tDBInput_1 = null;
				conn_tDBInput_1 = (java.sql.Connection) globalMap.get("conn_tDBConnection_1");

				if (conn_tDBInput_1 != null) {
					if (conn_tDBInput_1.getMetaData() != null) {

						log.debug("tDBInput_1 - Uses an existing connection with username '"
								+ conn_tDBInput_1.getMetaData().getUserName() + "'. Connection URL: "
								+ conn_tDBInput_1.getMetaData().getURL() + ".");

					}
				}

				java.sql.Statement stmt_tDBInput_1 = conn_tDBInput_1.createStatement();

				String dbquery_tDBInput_1 = "SELECT \n  `atlas_superstore_commandes`.`NUMERO_COMMANDE`, \n  `atlas_superstore_commandes`.`CODE_CLIENT`, \n  `atlas_supe"
						+ "rstore_commandes`.`REFERENCE_PRODUIT`, \n  `atlas_superstore_commandes`.`QUANTITE`, \n  `atlas_superstore_commandes`.`DATE"
						+ "_COMMANDE`, \n  `atlas_superstore_commandes`.`IS_COMMANDE_ANNULEE`, \n  `atlas_superstore_commandes`.`NOM_MAGASIN`, \n  `at"
						+ "las_superstore_commandes`.`PAYS_MAGASIN`\nFROM `atlas_superstore_commandes`";

				log.debug("tDBInput_1 - Executing the query: '" + dbquery_tDBInput_1 + "'.");

				globalMap.put("tDBInput_1_QUERY", dbquery_tDBInput_1);

				java.sql.ResultSet rs_tDBInput_1 = null;

				try {
					rs_tDBInput_1 = stmt_tDBInput_1.executeQuery(dbquery_tDBInput_1);
					java.sql.ResultSetMetaData rsmd_tDBInput_1 = rs_tDBInput_1.getMetaData();
					int colQtyInRs_tDBInput_1 = rsmd_tDBInput_1.getColumnCount();

					String tmpContent_tDBInput_1 = null;

					log.debug("tDBInput_1 - Retrieving records from the database.");

					while (rs_tDBInput_1.next()) {
						nb_line_tDBInput_1++;

						if (colQtyInRs_tDBInput_1 < 1) {
							Cdes.numero_commande = 0;
						} else {

							Cdes.numero_commande = rs_tDBInput_1.getInt(1);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 2) {
							Cdes.code_client = 0;
						} else {

							Cdes.code_client = rs_tDBInput_1.getInt(2);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 3) {
							Cdes.reference_produit = null;
						} else {

							Cdes.reference_produit = routines.system.JDBCUtil.getString(rs_tDBInput_1, 3, true);
						}
						if (colQtyInRs_tDBInput_1 < 4) {
							Cdes.quantite = 0;
						} else {

							Cdes.quantite = rs_tDBInput_1.getInt(4);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 5) {
							Cdes.date_commande = null;
						} else {

							if (rs_tDBInput_1.getString(5) != null) {
								String dateString_tDBInput_1 = rs_tDBInput_1.getString(5);
								if (!("0000-00-00").equals(dateString_tDBInput_1)
										&& !("0000-00-00 00:00:00").equals(dateString_tDBInput_1)) {
									Cdes.date_commande = rs_tDBInput_1.getTimestamp(5);
								} else {
									Cdes.date_commande = (java.util.Date) year0_tDBInput_1.clone();
								}
							} else {
								Cdes.date_commande = null;
							}
						}
						if (colQtyInRs_tDBInput_1 < 6) {
							Cdes.is_commande_annulee = 0;
						} else {

							Cdes.is_commande_annulee = rs_tDBInput_1.getInt(6);
							if (rs_tDBInput_1.wasNull()) {
								throw new RuntimeException("Null value in non-Nullable column");
							}
						}
						if (colQtyInRs_tDBInput_1 < 7) {
							Cdes.nom_magasin = null;
						} else {

							Cdes.nom_magasin = routines.system.JDBCUtil.getString(rs_tDBInput_1, 7, true);
						}
						if (colQtyInRs_tDBInput_1 < 8) {
							Cdes.pays_magasin = null;
						} else {

							Cdes.pays_magasin = routines.system.JDBCUtil.getString(rs_tDBInput_1, 8, true);
						}

						log.debug("tDBInput_1 - Retrieving the record " + nb_line_tDBInput_1 + ".");

						/**
						 * [tDBInput_1 begin ] stop
						 */

						/**
						 * [tDBInput_1 main ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "Cde_mariadb";

						tos_count_tDBInput_1++;

						/**
						 * [tDBInput_1 main ] stop
						 */

						/**
						 * [tDBInput_1 process_data_begin ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "Cde_mariadb";

						/**
						 * [tDBInput_1 process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_Cdes main ] start
						 */

						currentComponent = "tAdvancedHash_Cdes";

						if (runStat.update(execStat, enableLogStash, iterateId, 1, 1

								, "Cdes", "tDBInput_1", "Cde_mariadb", "tMysqlInput", "tAdvancedHash_Cdes",
								"tAdvancedHash_Cdes", "tAdvancedHash"

						)) {
							talendJobLogProcess(globalMap);
						}

						if (log.isTraceEnabled()) {
							log.trace("Cdes - " + (Cdes == null ? "" : Cdes.toLogString()));
						}

						CdesStruct Cdes_HashRow = new CdesStruct();

						Cdes_HashRow.numero_commande = Cdes.numero_commande;

						Cdes_HashRow.code_client = Cdes.code_client;

						Cdes_HashRow.reference_produit = Cdes.reference_produit;

						Cdes_HashRow.quantite = Cdes.quantite;

						Cdes_HashRow.date_commande = Cdes.date_commande;

						Cdes_HashRow.is_commande_annulee = Cdes.is_commande_annulee;

						Cdes_HashRow.nom_magasin = Cdes.nom_magasin;

						Cdes_HashRow.pays_magasin = Cdes.pays_magasin;

						tHash_Lookup_Cdes.put(Cdes_HashRow);

						tos_count_tAdvancedHash_Cdes++;

						/**
						 * [tAdvancedHash_Cdes main ] stop
						 */

						/**
						 * [tAdvancedHash_Cdes process_data_begin ] start
						 */

						currentComponent = "tAdvancedHash_Cdes";

						/**
						 * [tAdvancedHash_Cdes process_data_begin ] stop
						 */

						/**
						 * [tAdvancedHash_Cdes process_data_end ] start
						 */

						currentComponent = "tAdvancedHash_Cdes";

						/**
						 * [tAdvancedHash_Cdes process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 process_data_end ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "Cde_mariadb";

						/**
						 * [tDBInput_1 process_data_end ] stop
						 */

						/**
						 * [tDBInput_1 end ] start
						 */

						currentComponent = "tDBInput_1";

						cLabel = "Cde_mariadb";

					}
				} finally {
					if (rs_tDBInput_1 != null) {
						rs_tDBInput_1.close();
					}
					if (stmt_tDBInput_1 != null) {
						stmt_tDBInput_1.close();
					}
				}
				globalMap.put("tDBInput_1_NB_LINE", nb_line_tDBInput_1);
				log.debug("tDBInput_1 - Retrieved records count: " + nb_line_tDBInput_1 + " .");

				if (log.isDebugEnabled())
					log.debug("tDBInput_1 - " + ("Done."));

				ok_Hash.put("tDBInput_1", true);
				end_Hash.put("tDBInput_1", System.currentTimeMillis());

				/**
				 * [tDBInput_1 end ] stop
				 */

				/**
				 * [tAdvancedHash_Cdes end ] start
				 */

				currentComponent = "tAdvancedHash_Cdes";

				tHash_Lookup_Cdes.endPut();

				if (runStat.updateStatAndLog(execStat, enableLogStash, resourceMap, iterateId, "Cdes", 2, 0,
						"tDBInput_1", "Cde_mariadb", "tMysqlInput", "tAdvancedHash_Cdes", "tAdvancedHash_Cdes",
						"tAdvancedHash", "output")) {
					talendJobLogProcess(globalMap);
				}

				ok_Hash.put("tAdvancedHash_Cdes", true);
				end_Hash.put("tAdvancedHash_Cdes", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_Cdes end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBInput_1 finally ] start
				 */

				currentComponent = "tDBInput_1";

				cLabel = "Cde_mariadb";

				/**
				 * [tDBInput_1 finally ] stop
				 */

				/**
				 * [tAdvancedHash_Cdes finally ] start
				 */

				currentComponent = "tAdvancedHash_Cdes";

				/**
				 * [tAdvancedHash_Cdes finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBInput_1_SUBPROCESS_STATE", 1);
	}

	public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tPostjob_1");
		org.slf4j.MDC.put("_subJobPid", "lUlEWc_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tPostjob_1 begin ] start
				 */

				ok_Hash.put("tPostjob_1", false);
				start_Hash.put("tPostjob_1", System.currentTimeMillis());

				currentComponent = "tPostjob_1";

				cLabel = "postjob";

				int tos_count_tPostjob_1 = 0;

				if (enableLogStash) {
					talendJobLog.addCM("tPostjob_1", "postjob", "tPostjob");
					talendJobLogProcess(globalMap);
				}

				/**
				 * [tPostjob_1 begin ] stop
				 */

				/**
				 * [tPostjob_1 main ] start
				 */

				currentComponent = "tPostjob_1";

				cLabel = "postjob";

				tos_count_tPostjob_1++;

				/**
				 * [tPostjob_1 main ] stop
				 */

				/**
				 * [tPostjob_1 process_data_begin ] start
				 */

				currentComponent = "tPostjob_1";

				cLabel = "postjob";

				/**
				 * [tPostjob_1 process_data_begin ] stop
				 */

				/**
				 * [tPostjob_1 process_data_end ] start
				 */

				currentComponent = "tPostjob_1";

				cLabel = "postjob";

				/**
				 * [tPostjob_1 process_data_end ] stop
				 */

				/**
				 * [tPostjob_1 end ] start
				 */

				currentComponent = "tPostjob_1";

				cLabel = "postjob";

				ok_Hash.put("tPostjob_1", true);
				end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if (execStat) {
					runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tDBClose_1Process(globalMap);

				/**
				 * [tPostjob_1 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tPostjob_1 finally ] start
				 */

				currentComponent = "tPostjob_1";

				cLabel = "postjob";

				/**
				 * [tPostjob_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}

	public void tDBClose_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "tDBClose_1");
		org.slf4j.MDC.put("_subJobPid", "GksLLB_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tDBClose_1 begin ] start
				 */

				ok_Hash.put("tDBClose_1", false);
				start_Hash.put("tDBClose_1", System.currentTimeMillis());

				currentComponent = "tDBClose_1";

				int tos_count_tDBClose_1 = 0;

				if (log.isDebugEnabled())
					log.debug("tDBClose_1 - " + ("Start to work."));
				if (log.isDebugEnabled()) {
					class BytesLimit65535_tDBClose_1 {
						public void limitLog4jByte() throws Exception {
							StringBuilder log4jParamters_tDBClose_1 = new StringBuilder();
							log4jParamters_tDBClose_1.append("Parameters:");
							log4jParamters_tDBClose_1.append("CONNECTION" + " = " + "tDBConnection_1");
							log4jParamters_tDBClose_1.append(" | ");
							log4jParamters_tDBClose_1.append("UNIFIED_COMPONENTS" + " = " + "tMysqlClose");
							log4jParamters_tDBClose_1.append(" | ");
							if (log.isDebugEnabled())
								log.debug("tDBClose_1 - " + (log4jParamters_tDBClose_1));
						}
					}
					new BytesLimit65535_tDBClose_1().limitLog4jByte();
				}
				if (enableLogStash) {
					talendJobLog.addCM("tDBClose_1", "tDBClose_1", "tMysqlClose");
					talendJobLogProcess(globalMap);
				}

				/**
				 * [tDBClose_1 begin ] stop
				 */

				/**
				 * [tDBClose_1 main ] start
				 */

				currentComponent = "tDBClose_1";

				java.sql.Connection conn_tDBClose_1 = (java.sql.Connection) globalMap.get("conn_tDBConnection_1");

				if (conn_tDBClose_1 != null && !conn_tDBClose_1.isClosed()) {

					log.debug("tDBClose_1 - Closing the connection 'tDBConnection_1' to the database.");

					conn_tDBClose_1.close();

					if ("com.mysql.cj.jdbc.Driver".equals((String) globalMap.get("driverClass_tDBConnection_1"))
							&& routines.system.BundleUtils.inOSGi()) {
						Class.forName("com.mysql.cj.jdbc.AbandonedConnectionCleanupThread").getMethod("checkedShutdown")
								.invoke(null, (Object[]) null);
					}

					log.debug("tDBClose_1 - Connection 'tDBConnection_1' to the database closed.");

				}

				tos_count_tDBClose_1++;

				/**
				 * [tDBClose_1 main ] stop
				 */

				/**
				 * [tDBClose_1 process_data_begin ] start
				 */

				currentComponent = "tDBClose_1";

				/**
				 * [tDBClose_1 process_data_begin ] stop
				 */

				/**
				 * [tDBClose_1 process_data_end ] start
				 */

				currentComponent = "tDBClose_1";

				/**
				 * [tDBClose_1 process_data_end ] stop
				 */

				/**
				 * [tDBClose_1 end ] start
				 */

				currentComponent = "tDBClose_1";

				if (log.isDebugEnabled())
					log.debug("tDBClose_1 - " + ("Done."));

				ok_Hash.put("tDBClose_1", true);
				end_Hash.put("tDBClose_1", System.currentTimeMillis());

				/**
				 * [tDBClose_1 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tDBClose_1 finally ] start
				 */

				currentComponent = "tDBClose_1";

				/**
				 * [tDBClose_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tDBClose_1_SUBPROCESS_STATE", 1);
	}

	public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		mdcInfo.forEach(org.slf4j.MDC::put);
		org.slf4j.MDC.put("_subJobName", "talendJobLog");
		org.slf4j.MDC.put("_subJobPid", "HeFB3A_" + subJobPidCounter.getAndIncrement());

		String iterateId = "";

		String currentComponent = "";
		String cLabel = null;
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [talendJobLog begin ] start
				 */

				ok_Hash.put("talendJobLog", false);
				start_Hash.put("talendJobLog", System.currentTimeMillis());

				currentComponent = "talendJobLog";

				int tos_count_talendJobLog = 0;

				for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
					org.talend.job.audit.JobContextBuilder builder_talendJobLog = org.talend.job.audit.JobContextBuilder
							.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
							.custom("process_id", jcm.pid).custom("thread_id", jcm.tid).custom("pid", pid)
							.custom("father_pid", fatherPid).custom("root_pid", rootPid);
					org.talend.logging.audit.Context log_context_talendJobLog = null;

					if (jcm.log_type == JobStructureCatcherUtils.LogType.PERFORMANCE) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.sourceId(jcm.sourceId)
								.sourceLabel(jcm.sourceLabel).sourceConnectorType(jcm.sourceComponentName)
								.targetId(jcm.targetId).targetLabel(jcm.targetLabel)
								.targetConnectorType(jcm.targetComponentName).connectionName(jcm.current_connector)
								.rows(jcm.row_count).duration(duration).build();
						auditLogger_talendJobLog.flowExecution(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBSTART) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).build();
						auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBEND) {
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment).duration(duration)
								.status(jcm.status).build();
						auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.RUNCOMPONENT) {
						log_context_talendJobLog = builder_talendJobLog.timestamp(jcm.moment)
								.connectorType(jcm.component_name).connectorId(jcm.component_id)
								.connectorLabel(jcm.component_label).build();
						auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWINPUT) {// log current component
																							// input line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.FLOWOUTPUT) {// log current component
																								// output/reject line
						long timeMS = jcm.end_time - jcm.start_time;
						String duration = String.valueOf(timeMS);

						log_context_talendJobLog = builder_talendJobLog.connectorType(jcm.component_name)
								.connectorId(jcm.component_id).connectorLabel(jcm.component_label)
								.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
								.rows(jcm.total_row_number).duration(duration).build();
						auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
					} else if (jcm.log_type == JobStructureCatcherUtils.LogType.JOBERROR) {
						java.lang.Exception e_talendJobLog = jcm.exception;
						if (e_talendJobLog != null) {
							try (java.io.StringWriter sw_talendJobLog = new java.io.StringWriter();
									java.io.PrintWriter pw_talendJobLog = new java.io.PrintWriter(sw_talendJobLog)) {
								e_talendJobLog.printStackTrace(pw_talendJobLog);
								builder_talendJobLog.custom("stacktrace", sw_talendJobLog.getBuffer().substring(0,
										java.lang.Math.min(sw_talendJobLog.getBuffer().length(), 512)));
							}
						}

						if (jcm.extra_info != null) {
							builder_talendJobLog.connectorId(jcm.component_id).custom("extra_info", jcm.extra_info);
						}

						log_context_talendJobLog = builder_talendJobLog
								.connectorType(jcm.component_id.substring(0, jcm.component_id.lastIndexOf('_')))
								.connectorId(jcm.component_id)
								.connectorLabel(jcm.component_label == null ? jcm.component_id : jcm.component_label)
								.build();

						auditLogger_talendJobLog.exception(log_context_talendJobLog);
					}

				}

				/**
				 * [talendJobLog begin ] stop
				 */

				/**
				 * [talendJobLog main ] start
				 */

				currentComponent = "talendJobLog";

				tos_count_talendJobLog++;

				/**
				 * [talendJobLog main ] stop
				 */

				/**
				 * [talendJobLog process_data_begin ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_begin ] stop
				 */

				/**
				 * [talendJobLog process_data_end ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog process_data_end ] stop
				 */

				/**
				 * [talendJobLog end ] start
				 */

				currentComponent = "talendJobLog";

				ok_Hash.put("talendJobLog", true);
				end_Hash.put("talendJobLog", System.currentTimeMillis());

				/**
				 * [talendJobLog end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			if (!(e instanceof TalendException)) {
				log.fatal(currentComponent + " " + e.getMessage(), e);
			}

			TalendException te = new TalendException(e, currentComponent, cLabel, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [talendJobLog finally ] start
				 */

				currentComponent = "talendJobLog";

				/**
				 * [talendJobLog finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	private final static java.util.Properties jobInfo = new java.util.Properties();
	private final static java.util.Map<String, String> mdcInfo = new java.util.HashMap<>();
	private final static java.util.concurrent.atomic.AtomicLong subJobPidCounter = new java.util.concurrent.atomic.AtomicLong();

	public static void main(String[] args) {
		final Atlas_superstore_cde Atlas_superstore_cdeClass = new Atlas_superstore_cde();

		int exitCode = Atlas_superstore_cdeClass.runJobInTOS(args);
		if (exitCode == 0) {
			log.info("TalendJob: 'Atlas_superstore_cde' - Done.");
		}

		System.exit(exitCode);
	}

	private void getjobInfo() {
		final String TEMPLATE_PATH = "src/main/templates/jobInfo_template.properties";
		final String BUILD_PATH = "../jobInfo.properties";
		final String path = this.getClass().getResource("").getPath();
		if (path.lastIndexOf("target") > 0) {
			final java.io.File templateFile = new java.io.File(
					path.substring(0, path.lastIndexOf("target")).concat(TEMPLATE_PATH));
			if (templateFile.exists()) {
				readJobInfo(templateFile);
				return;
			}
		}
		readJobInfo(new java.io.File(BUILD_PATH));
	}

	private void readJobInfo(java.io.File jobInfoFile) {

		if (jobInfoFile.exists()) {
			try (java.io.InputStream is = new java.io.FileInputStream(jobInfoFile)) {
				jobInfo.load(is);
			} catch (IOException e) {

				log.debug("Read jobInfo.properties file fail: " + e.getMessage());

			}
		}
		log.info(String.format("Project name: %s\tJob name: %s\tGIT Commit ID: %s\tTalend Version: %s", projectName,
				jobName, jobInfo.getProperty("gitCommitId"), "8.0.1.20230815_1353-patch"));

	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (!"".equals(log4jLevel)) {

			if ("trace".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.TRACE);
			} else if ("debug".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.DEBUG);
			} else if ("info".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.INFO);
			} else if ("warn".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.WARN);
			} else if ("error".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.ERROR);
			} else if ("fatal".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.FATAL);
			} else if ("off".equalsIgnoreCase(log4jLevel)) {
				org.apache.logging.log4j.core.config.Configurator.setLevel(log.getName(),
						org.apache.logging.log4j.Level.OFF);
			}
			org.apache.logging.log4j.core.config.Configurator
					.setLevel(org.apache.logging.log4j.LogManager.getRootLogger().getName(), log.getLevel());

		}

		getjobInfo();
		log.info("TalendJob: 'Atlas_superstore_cde' - Start.");

		java.util.Set<Object> jobInfoKeys = jobInfo.keySet();
		for (Object jobInfoKey : jobInfoKeys) {
			org.slf4j.MDC.put("_" + jobInfoKey.toString(), jobInfo.get(jobInfoKey).toString());
		}
		org.slf4j.MDC.put("_pid", pid);
		org.slf4j.MDC.put("_rootPid", rootPid);
		org.slf4j.MDC.put("_fatherPid", fatherPid);
		org.slf4j.MDC.put("_projectName", projectName);
		org.slf4j.MDC.put("_startTimestamp", java.time.ZonedDateTime.now(java.time.ZoneOffset.UTC)
				.format(java.time.format.DateTimeFormatter.ISO_INSTANT));
		org.slf4j.MDC.put("_jobRepositoryId", "_EomQIGRfEe6hdfxx25NesQ");
		org.slf4j.MDC.put("_compiledAtTimestamp", "2023-10-20T09:32:38.328649700Z");

		java.lang.management.RuntimeMXBean mx = java.lang.management.ManagementFactory.getRuntimeMXBean();
		String[] mxNameTable = mx.getName().split("@"); //$NON-NLS-1$
		if (mxNameTable.length == 2) {
			org.slf4j.MDC.put("_systemPid", mxNameTable[0]);
		} else {
			org.slf4j.MDC.put("_systemPid", String.valueOf(java.lang.Thread.currentThread().getId()));
		}

		if (enableLogStash) {
			java.util.Properties properties_talendJobLog = new java.util.Properties();
			properties_talendJobLog.setProperty("root.logger", "audit");
			properties_talendJobLog.setProperty("encoding", "UTF-8");
			properties_talendJobLog.setProperty("application.name", "Talend Studio");
			properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
			properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
			properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
			properties_talendJobLog.setProperty("log.appender", "file");
			properties_talendJobLog.setProperty("appender.file.path", "audit.json");
			properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
			properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
			properties_talendJobLog.setProperty("host", "false");

			System.getProperties().stringPropertyNames().stream().filter(it -> it.startsWith("audit.logger."))
					.forEach(key -> properties_talendJobLog.setProperty(key.substring("audit.logger.".length()),
							System.getProperty(key)));

			org.apache.logging.log4j.core.config.Configurator
					.setLevel(properties_talendJobLog.getProperty("root.logger"), org.apache.logging.log4j.Level.DEBUG);

			auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory
					.createJobAuditLogger(properties_talendJobLog);
		}

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		org.slf4j.MDC.put("_pid", pid);

		if (rootPid == null) {
			rootPid = pid;
		}

		org.slf4j.MDC.put("_rootPid", rootPid);

		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}
		org.slf4j.MDC.put("_fatherPid", fatherPid);

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		try {
			java.util.Dictionary<String, Object> jobProperties = null;
			if (inOSGi) {
				jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

				if (jobProperties != null && jobProperties.get("context") != null) {
					contextStr = (String) jobProperties.get("context");
				}
			}
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = Atlas_superstore_cde.class.getClassLoader()
					.getResourceAsStream("tmc_git/atlas_superstore_cde_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = Atlas_superstore_cde.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						if (inOSGi && jobProperties != null) {
							java.util.Enumeration<String> keys = jobProperties.keys();
							while (keys.hasMoreElements()) {
								String propKey = keys.nextElement();
								if (defaultProps.containsKey(propKey)) {
									defaultProps.put(propKey, (String) jobProperties.get(propKey));
								}
							}
						}
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, ContextProperties.class, parametersToEncrypt));

		org.slf4j.MDC.put("_context", contextStr);
		log.info("TalendJob: 'Atlas_superstore_cde' - Started.");
		java.util.Optional.ofNullable(org.slf4j.MDC.getCopyOfContextMap()).ifPresent(mdcInfo::putAll);

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		if (enableLogStash) {
			talendJobLog.addJobStartMessage();
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tDBConnection_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tDBConnection_1) {
			globalMap.put("tDBConnection_1_SUBPROCESS_STATE", -1);

			e_tDBConnection_1.printStackTrace();

		}
		try {
			errorCode = null;
			tFileInputDelimited_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_1) {
			globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_1.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		try {
			errorCode = null;
			tPostjob_1Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tPostjob_1) {
			globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

			e_tPostjob_1.printStackTrace();

		}

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println(
					(endUsedMemory - startUsedMemory) + " bytes memory increase when running : Atlas_superstore_cde");
		}
		if (enableLogStash) {
			talendJobLog.addJobEndMessage(startTime, end, status);
			try {
				talendJobLogProcess(globalMap);
			} catch (java.lang.Exception e) {
				e.printStackTrace();
			}
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");
		resumeUtil.flush();

		org.slf4j.MDC.remove("_subJobName");
		org.slf4j.MDC.remove("_subJobPid");
		org.slf4j.MDC.remove("_systemPid");
		log.info("TalendJob: 'Atlas_superstore_cde' - Finished - status: " + status + " returnCode: " + returnCode);

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {
		closeSqlDbConnections();

	}

	private void closeSqlDbConnections() {
		try {
			Object obj_conn;
			obj_conn = globalMap.remove("conn_tDBConnection_1");
			if (null != obj_conn) {
				((java.sql.Connection) obj_conn).close();
			}
		} catch (java.lang.Exception e) {
		}
	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
		connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 266873 characters generated by Talend Cloud Data Fabric on the 20 octobre
 * 2023 à 11:32:38 CEST
 ************************************************************************************************/